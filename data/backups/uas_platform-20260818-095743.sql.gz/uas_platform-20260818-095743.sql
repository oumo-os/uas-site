-- UAS Institutional Platform backup
-- Generated: 2026-08-18 09:57:43
-- Tables: articles, assignments, audit_log, budget_items, calendar_items, capabilities, contact_messages, documents, event_registrations, event_waitlist, events, financial_records, members, notifications, partners, programmes, projects, rate_limits, resolution_changes, resolution_comments, resolutions, role_assignments, role_capabilities, roles, useful_links, users, votes, workflow_states, working_group_members, working_groups

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `body` longtext DEFAULT NULL,
  `category` enum('article','observing_report','educational','project_report','announcement','paper') DEFAULT 'article',
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `image_url` varchar(500) DEFAULT NULL,
  `status` enum('draft','submitted','under_review','approved','published','rejected','archived') DEFAULT 'draft',
  `approver_role_id` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `approver_role_id` (`approver_role_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `articles_ibfk_2` FOREIGN KEY (`approver_role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `articles_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `articles` VALUES ('2', '7', 'First Light at Makerere Observatory', '<p>On a clear night in August, we gathered at Makerere University to commission the first telescope of our outreach programme.</p><h2>What we did</h2><p>Students aligned the instrument, calibrated the finder scope, and took turns observing Jupiter and its four Galilean moons. The session ran from 7pm to 10pm with over 40 participants.</p><h2>Key takeaways</h2><p>The event confirmed strong public appetite for observing sessions. We will run monthly public nights and partner with university physics departments for student volunteers.</p>', 'observing_report', '[\"observing\",\"education\"]', NULL, 'published', NULL, NULL, NULL, '2026-08-13 19:54:43', NULL, '2026-08-13 19:54:11', '2026-08-14 11:32:33');
INSERT INTO `articles` VALUES ('3', '9', 'Aurora Hunting in the Tropics: What Ugandan Skygazers Can See', '<p>Aurorae are famously a high-latitude phenomenon, but tropical skygazers still get remarkable celestial spectacles — from zodiacal light after dusk to brilliant meteors.</p><h2>Zodiacal light</h2><p>In the weeks around the equinoxes, look west after sunset or east before dawn for a soft cone of light rising from the horizon. It is sunlight scattered off interplanetary dust.</p><h2>Noctilucent clouds</h2><p>Occasionally visible near the poles of our sky at twilight, these glowing clouds form at ~80 km altitude.</p><p>Download our monthly sky map from the Library to plan your next session.</p>', 'educational', '[\"aurora\",\"outreach\",\"tropics\"]', NULL, 'published', NULL, '2', '2026-08-02 10:00:00', '2026-08-02 10:00:00', NULL, '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `articles` VALUES ('4', '3', 'Announcement: Monthly Public Observing Nights at Kololo', '<p>The Society is delighted to announce that public observing nights now run every first Friday of the month at Kololo Airstrip, Kampala, weather permitting.</p><p>Each session features a short talk, telescope guidance for beginners, and a featured target of the month. Entry is free for members and 5,000 UGX for guests.</p><p>Follow the Events page and RSVP to reserve a telescope slot.</p>', 'announcement', '[\"events\",\"observing\"]', NULL, 'published', NULL, '2', '2026-07-18 09:00:00', '2026-07-18 09:00:00', NULL, '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `articles` VALUES ('5', '10', 'Uganda in the 2027 Total Solar Eclipse Path', '<p>The total solar eclipse of 2 August 2027 will cross northern Africa and the Middle East. Uganda lies just outside the path of totality, but a substantial partial eclipse will be visible across the entire country.</p><h2>What to expect</h2><p>In Kampala, the Moon will cover roughly 45% of the Sun at maximum. Never look at the partial phases without certified eclipse glasses.</p><h2>The Society\'s plan</h2><p>UAS will run coordinated public viewing sessions and school outreach kits in the weeks before the event.</p>', 'educational', '[\"eclipse\",\"2027\"]', NULL, 'published', NULL, '2', '2026-08-10 14:00:00', '2026-08-10 14:00:00', NULL, '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `articles` VALUES ('6', '4', 'Report: School Telescope Programme Pilot', '<p>The pilot phase of the School Telescope Programme delivered instruments and teacher training to three schools in Kampala and Wakiso districts.</p><h2>Outcomes</h2><ul><li>3 schools equipped with 6-inch Dobsonian telescopes</li><li>14 teachers trained in basic astronomy and instrument care</li><li>Established school astronomy clubs with 120+ learners</li></ul><p>Full rollout to 10 schools is scheduled by December 2026.</p>', 'project_report', '[\"schools\",\"telescopes\",\"impact\"]', NULL, 'published', NULL, '2', '2026-07-25 11:30:00', '2026-07-25 11:30:00', NULL, '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `articles` VALUES ('7', '9', 'Grace Note: How to plan a school observing night', '<p>Step by step guide from the field.</p>', 'educational', '[\"outreach\"]', NULL, 'published', NULL, NULL, NULL, '2026-08-14 13:23:30', NULL, '2026-08-14 13:23:07', '2026-08-14 15:28:15');
INSERT INTO `articles` VALUES ('8', '7', 'Draft observing plan (test reject)', '<p>body</p>', 'article', '[]', NULL, 'rejected', NULL, '1', '2026-08-14 13:35:22', NULL, 'Duplicate of existing plan; revise and resubmit', '2026-08-14 13:35:22', '2026-08-14 13:35:22');
INSERT INTO `articles` VALUES ('11', '1', 'Understanding Redshift: A Guide for Amateur Astronomers', '<p>Redshift is one of the most important concepts in astronomy. It describes how light from distant objects is stretched to longer (redder) wavelengths as the universe expands.</p><p>For amateur astronomers, understanding redshift helps contextualize the objects you observe. When you look at a galaxy through your telescope, its light may have traveled billions of years to reach you, stretched by the expansion of space along the way.</p><h3>Types of Redshift</h3><p>There are three main types: cosmological (due to universe expansion), Doppler (due to relative motion), and gravitational (due to strong gravity fields near massive objects).</p><p>The Hubble-Lemaître Law relates a galaxy\'s redshift to its distance, forming the foundation of our understanding of the expanding universe.</p>', 'educational', NULL, 'astronomy-redshift.jpg', 'published', NULL, NULL, NULL, '2026-08-18 09:33:55', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `articles` VALUES ('12', '2', 'Building a DIY Solar Filter for Safe Sun Observation', '<p>Solar observation requires proper filtration to protect your eyes and equipment. A Baader film solar filter is the safest and most affordable option for telescopic solar viewing.</p><p>This guide walks you through constructing a cell-mounted solar filter for popular telescope apertures. You will need Baader AstroSolar film (ND 5.0), a cardboard or wooden cell, and basic crafting tools.</p><h3>Materials</h3><p>Baader AstroSolar Safety Film (OD 5.0), 1-2mm thick cardboard or foam board, black acrylic paint, scissors, ruler, and adhesive.</p><h3>Steps</h3><p>Measure your telescope aperture. Cut concentric rings to create a friction-fit cell. Paint the interior matte black. Secure the solar film over the aperture using retaining rings. The filter must fit snugly and cannot fall off during use.</p><p>Always use the full-aperture filter at the front of the telescope. Never use eyepiece-mounted filters for solar observation — they can crack from heat.</p>', 'educational', NULL, 'solar-filter.jpg', 'published', NULL, NULL, NULL, '2026-08-18 09:33:55', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `articles` VALUES ('13', '3', 'Uganda Dark Sky Sites: A Comprehensive Guide', '<p>Uganda hosts several excellent dark sky locations ideal for astronomical observation. This guide catalogs the best sites based on light pollution measurements and accessibility.</p><h3>Tier 1 — Pristine Skies</h3><p><strong>Murchison Falls National Park</strong>: Bortle 2 skies. The park offers expansive horizons and minimal artificial lighting. Best visited during dry seasons (December-February, June-September).</p><p><strong>Lake Mburo National Park</strong>: Bortle 2-3. Closer to Kampala than Murchison, with good road access and camping facilities.</p><h3>Tier 2 — Good Skies</h3><p><strong>Mount Elgon National Park</strong>: Bortle 3. Higher altitude provides thinner atmosphere and better seeing conditions. Some light pollution from nearby towns.</p><p><strong>Queen Elizabeth National Park</strong>: Bortle 3-4. Good for wide-field observation but Kasenyi tourism area has some light pollution.</p><h3>Urban Observing</h3><p>Within Kampala, Kololo Airstrip remains the best urban observing site due to its open space and distance from heavy commercial lighting.</p>', 'observing_report', NULL, 'dark-sites.jpg', 'published', NULL, NULL, NULL, '2026-08-18 09:33:55', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `articles` VALUES ('14', '1', 'The Physics of Black Holes: What We Know in 2026', '<p>Black holes remain among the most fascinating objects in the universe. Here is our current understanding as of 2026.</p><h3>Formation</h3><p>Stellar-mass black holes form from the gravitational collapse of massive stars (typically >25 solar masses) at the end of their lives. Supermassive black holes (millions to billions of solar masses) sit at the centers of galaxies, including our own Milky Way\'s Sagittarius A*.</p><h3>Observation</h3><p>While black holes themselves emit no light, we detect them through their effects: accretion disks of heated material, gravitational lensing of background stars, gravitational waves from mergers, and the motion of nearby stars.</p><p>The Event Horizon Telescope collaboration continues to image black hole shadows, with increasing resolution revealing structure in the accretion flow around M87* and Sgr A*.</p><h3>Information Paradox</h3><p>The black hole information paradox remains an active area of research. Recent theoretical work suggests information may be encoded in Hawking radiation or stored in a remnant at the horizon.</p>', 'educational', NULL, 'blackholes.jpg', 'published', NULL, NULL, NULL, '2026-08-18 09:33:55', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `articles` VALUES ('15', '4', 'Report: Kampala International School Telescope Installation', '<p>UAS completed the installation and commissioning of a 12-inch Dobsonian telescope at Kampala International School on 15 August 2026. This is the third installation under the School Telescope Programme.</p><h3>Installation Details</h3><p>Equipment: Sky-Watcher Dobsonian 12\" Collapsible, two eyepieces (25mm, 10mm), Telrad finder, and a basic star atlas. The school provided storage space and a commitment to regular usage.</p><h3>Training</h3><p>A two-hour training session covered telescope assembly, collimation, basic star-hopping, and safety protocols. Twelve students and two teachers participated.</p><h3>Impact</h3><p>The telescope has already been used for three after-school observation sessions. Students reported seeing Jupiter\'s moons, Saturn\'s rings, and the Orion Nebula for the first time.</p><p>UAS will follow up quarterly and provide ongoing support to the school\'s astronomy club.</p>', 'project_report', NULL, 'kis-telescope.jpg', 'published', NULL, NULL, NULL, '2026-08-18 09:33:55', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `articles` VALUES ('16', '2', 'Announcement: New Partnership with Uganda Wildlife Authority', '<p>Uganda Astronomical Society is pleased to announce a formal partnership with the Uganda Wildlife Authority (UWA) to establish astronomy tourism programs in national parks.</p><p>This partnership will enable:</p><ul><li>Regular star-gazing events at Murchison Falls, Lake Mburo, and Queen Elizabeth National Parks</li><li>Training for UWA rangers as astronomy guides</li><li>Development of astronomy tourism marketing materials</li><li>Research collaboration on light pollution monitoring in protected areas</li></ul><p>The first joint event is planned for October 2026 at Lake Mburo National Park. Details will be shared on our events page.</p>', 'announcement', NULL, 'uwa-partnership.jpg', 'published', NULL, NULL, NULL, '2026-08-18 09:33:55', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `articles` VALUES ('17', '1', 'Monthly Sky Guide: September 2026', '<p>Here is what to look for in the night sky this September from Uganda.</p><h3>Planets</h3><p><strong>Jupiter</strong> rises around 22:00 and is excellent for observation in the early morning hours. Look for the four Galilean moons.</p><p><strong>Saturn</strong> is visible all night, with its rings tilted at a favorable angle. A 4-inch telescope reveals the Cassini division.</p><p><strong>Mars</strong> is currently on the far side of the Sun and not well placed for observation.</p><h3>Moon Phases</h3><p>New Moon: September 1 | First Quarter: September 8 | Full Moon: September 15 | Last Quarter: September 22</p><h3>Highlights</h3><p>The September equinox falls on September 22. Day and night will be approximately equal in length.</p><p>The Autumnal Equinox is a good time to observe the Milky Way stretching across the sky before moonrise.</p>', 'announcement', NULL, 'sky-guide.jpg', 'published', NULL, NULL, NULL, '2026-08-18 09:33:55', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');

DROP TABLE IF EXISTS `assignments`;
CREATE TABLE `assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `assignee_id` int(11) DEFAULT NULL,
  `assigner_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `status` enum('not_started','in_progress','submitted','completed','overdue') DEFAULT 'not_started',
  `related_type` varchar(100) DEFAULT NULL,
  `related_id` int(11) DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `completion_evidence` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `assignee_id` (`assignee_id`),
  KEY `assigner_id` (`assigner_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `assignments_ibfk_1` FOREIGN KEY (`assignee_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `assignments_ibfk_2` FOREIGN KEY (`assigner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `assignments_ibfk_3` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `assignments` VALUES ('1', 'Draft Star Party 2026 operations plan', NULL, '4', '2', NULL, '2026-08-30', 'high', 'not_started', NULL, NULL, NULL, NULL, '2026-08-14 09:42:35', '2026-08-14 09:42:35');
INSERT INTO `assignments` VALUES ('2', 'Write observing report for August public night', NULL, '7', '4', NULL, '2026-08-28', 'high', 'completed', NULL, NULL, '2026-08-14 11:32:51', 'Draft posted to Google Drive: https://drive.google.com/draft-v1', '2026-08-14 11:32:41', '2026-08-14 11:32:51');
INSERT INTO `assignments` VALUES ('3', 'Compile star party safety checklist', 'Consolidate safety rules for public observing events', '9', '4', NULL, '2026-08-22', 'medium', 'not_started', NULL, NULL, NULL, NULL, '2026-08-14 13:18:38', '2026-08-14 13:18:38');
INSERT INTO `assignments` VALUES ('4', 'Draft school outreach lesson plan', 'One-hour lesson on phases of the Moon for P6/P7', '8', '4', NULL, '2026-08-30', 'high', 'not_started', NULL, NULL, NULL, NULL, '2026-08-14 13:18:38', '2026-08-14 13:18:38');
INSERT INTO `assignments` VALUES ('5', 'Review eclipse viewing safety materials', 'Check IAU 2027 eclipse safety factsheet translation', '10', '4', NULL, '2026-08-01', 'urgent', 'overdue', NULL, NULL, NULL, NULL, '2026-08-14 13:18:38', '2026-08-14 13:18:38');
INSERT INTO `assignments` VALUES ('6', 'Draft observing report', 'Summarise last week session', '5', '1', NULL, '2026-09-01', 'medium', 'not_started', NULL, NULL, NULL, NULL, '2026-08-14 16:00:09', '2026-08-14 16:00:09');

DROP TABLE IF EXISTS `audit_log`;
CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `action_type` varchar(50) NOT NULL,
  `target_type` varchar(100) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `governance_context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`governance_context`)),
  `previous_state` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`previous_state`)),
  `new_state` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_state`)),
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_action` (`action_type`),
  KEY `idx_audit_target` (`target_type`,`target_id`),
  KEY `idx_audit_date` (`created_at`),
  CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=346 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `audit_log` VALUES ('1', NULL, NULL, 'role_create', 'role', '1', NULL, NULL, NULL, '{\"title\":\"Board Director\",\"capabilities\":[]}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('2', NULL, NULL, 'role_assign', 'role', '1', NULL, NULL, NULL, '{\"user_id\":2,\"assigned_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('3', NULL, NULL, 'role_assign', 'role', '1', NULL, NULL, NULL, '{\"user_id\":3,\"assigned_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('4', NULL, NULL, 'role_assign', 'role', '1', NULL, NULL, NULL, '{\"user_id\":4,\"assigned_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('5', NULL, NULL, 'role_assign', 'role', '1', NULL, NULL, NULL, '{\"user_id\":5,\"assigned_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('6', NULL, NULL, 'cap_assign', 'role', '2', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('7', NULL, NULL, 'cap_assign', 'role', '2', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('8', NULL, NULL, 'cap_assign', 'role', '2', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('9', NULL, NULL, 'cap_assign', 'role', '2', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('10', NULL, NULL, 'cap_assign', 'role', '2', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('11', NULL, NULL, 'role_create', 'role', '2', NULL, NULL, NULL, '{\"title\":\"PR Director\",\"capabilities\":[3,4,5,10,11]}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('12', NULL, NULL, 'cap_assign', 'role', '3', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('13', NULL, NULL, 'cap_assign', 'role', '3', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('14', NULL, NULL, 'cap_assign', 'role', '3', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('15', NULL, NULL, 'cap_assign', 'role', '3', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('16', NULL, NULL, 'role_create', 'role', '3', NULL, NULL, NULL, '{\"title\":\"Education WG Lead\",\"capabilities\":[4,10,14,34]}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('17', NULL, NULL, 'cap_assign', 'role', '4', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('18', NULL, NULL, 'cap_assign', 'role', '4', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('19', NULL, NULL, 'cap_assign', 'role', '4', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('20', NULL, NULL, 'cap_assign', 'role', '4', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('21', NULL, NULL, 'role_create', 'role', '4', NULL, NULL, NULL, '{\"title\":\"Programme Lead\",\"capabilities\":[14,18,10,34]}', '2026-08-13 19:18:17');
INSERT INTO `audit_log` VALUES ('22', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:18:41');
INSERT INTO `audit_log` VALUES ('23', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:18:49');
INSERT INTO `audit_log` VALUES ('24', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:46:28');
INSERT INTO `audit_log` VALUES ('25', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:47:07');
INSERT INTO `audit_log` VALUES ('26', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:47:33');
INSERT INTO `audit_log` VALUES ('27', '1', 'System Admin', 'resolution_create', 'resolution', '1', NULL, NULL, NULL, '{\"code\":\"UAS-BRD-2026-001\",\"type\":\"role_create\",\"proposed_by\":1}', '2026-08-13 19:47:33');
INSERT INTO `audit_log` VALUES ('28', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:47:37');
INSERT INTO `audit_log` VALUES ('29', '1', 'System Admin', 'resolution_create', 'resolution', '2', NULL, NULL, NULL, '{\"code\":\"UAS-BRD-2026-002\",\"type\":\"role_create\",\"proposed_by\":1}', '2026-08-13 19:47:38');
INSERT INTO `audit_log` VALUES ('30', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:48:02');
INSERT INTO `audit_log` VALUES ('31', '1', 'System Admin', 'resolution_create', 'resolution', '3', NULL, NULL, NULL, '{\"code\":\"UAS-BRD-2026-001\",\"type\":\"role_create\",\"proposed_by\":1}', '2026-08-13 19:48:02');
INSERT INTO `audit_log` VALUES ('32', '1', 'System Admin', 'resolution_submit', 'resolution', '3', NULL, NULL, NULL, NULL, '2026-08-13 19:48:02');
INSERT INTO `audit_log` VALUES ('33', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:48:10');
INSERT INTO `audit_log` VALUES ('34', '1', 'System Admin', 'resolution_voting', 'resolution', '3', NULL, NULL, NULL, NULL, '2026-08-13 19:48:10');
INSERT INTO `audit_log` VALUES ('35', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:48:46');
INSERT INTO `audit_log` VALUES ('36', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-13 19:48:46');
INSERT INTO `audit_log` VALUES ('37', '3', 'Malcom Kintu', 'login', 'user', '3', NULL, NULL, NULL, NULL, '2026-08-13 19:48:46');
INSERT INTO `audit_log` VALUES ('38', '1', 'System Admin', 'resolution_vote', 'resolution', '3', NULL, NULL, NULL, '{\"user_id\":1,\"value\":\"for\"}', '2026-08-13 19:48:46');
INSERT INTO `audit_log` VALUES ('39', '2', 'Cosmus Ngabirano', 'resolution_vote', 'resolution', '3', NULL, NULL, NULL, '{\"user_id\":2,\"value\":\"for\"}', '2026-08-13 19:48:47');
INSERT INTO `audit_log` VALUES ('40', '3', 'Malcom Kintu', 'resolution_vote', 'resolution', '3', NULL, NULL, NULL, '{\"user_id\":3,\"value\":\"for\"}', '2026-08-13 19:48:47');
INSERT INTO `audit_log` VALUES ('41', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:48:51');
INSERT INTO `audit_log` VALUES ('42', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('43', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('44', '3', 'Malcom Kintu', 'login', 'user', '3', NULL, NULL, NULL, NULL, '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('45', '1', 'System Admin', 'resolution_vote', 'resolution', '3', NULL, NULL, NULL, '{\"user_id\":1,\"value\":\"for\"}', '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('46', '2', 'Cosmus Ngabirano', 'resolution_vote', 'resolution', '3', NULL, NULL, NULL, '{\"user_id\":2,\"value\":\"for\"}', '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('47', '3', 'Malcom Kintu', 'resolution_vote', 'resolution', '3', NULL, NULL, NULL, '{\"user_id\":3,\"value\":\"for\"}', '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('48', '3', 'Malcom Kintu', 'resolution_passed', 'resolution', '3', NULL, NULL, NULL, NULL, '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('49', '3', 'Malcom Kintu', 'cap_assign', 'role', '5', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('50', '3', 'Malcom Kintu', 'cap_assign', 'role', '5', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('51', '3', 'Malcom Kintu', 'role_create', 'role', '5', '{\"resolution_id\":3}', NULL, NULL, '{\"title\":\"Head of Science\",\"capabilities\":[4,5]}', '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('52', '3', 'Malcom Kintu', 'resolution_change_applied', 'resolution_change', '5', '{\"resolution_id\":3}', NULL, NULL, '{\"change_type\":\"role_create\"}', '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('53', '3', 'Malcom Kintu', 'resolution_applied', 'resolution', '3', NULL, NULL, NULL, NULL, '2026-08-13 19:49:54');
INSERT INTO `audit_log` VALUES ('54', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:50:00');
INSERT INTO `audit_log` VALUES ('55', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:50:09');
INSERT INTO `audit_log` VALUES ('56', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:50:18');
INSERT INTO `audit_log` VALUES ('57', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('58', '3', 'Malcom Kintu', 'login', 'user', '3', NULL, NULL, NULL, NULL, '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('59', '1', 'System Admin', 'resolution_create', 'resolution', '4', NULL, NULL, NULL, '{\"code\":\"UAS-BRD-2026-002\",\"type\":\"appoint\",\"proposed_by\":1}', '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('60', '1', 'System Admin', 'resolution_submit', 'resolution', '4', NULL, NULL, NULL, NULL, '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('61', '1', 'System Admin', 'resolution_voting', 'resolution', '4', NULL, NULL, NULL, NULL, '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('62', '1', 'System Admin', 'resolution_vote', 'resolution', '4', NULL, NULL, NULL, '{\"user_id\":1,\"value\":\"for\"}', '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('63', '2', 'Cosmus Ngabirano', 'resolution_vote', 'resolution', '4', NULL, NULL, NULL, '{\"user_id\":2,\"value\":\"for\"}', '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('64', '3', 'Malcom Kintu', 'resolution_vote', 'resolution', '4', NULL, NULL, NULL, '{\"user_id\":3,\"value\":\"for\"}', '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('65', '3', 'Malcom Kintu', 'resolution_passed', 'resolution', '4', NULL, NULL, NULL, NULL, '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('66', '3', 'Malcom Kintu', 'role_assign', 'role', '5', '{\"resolution_id\":4}', NULL, NULL, '{\"user_id\":4,\"assigned_by\":1}', '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('67', '3', 'Malcom Kintu', 'resolution_change_applied', 'resolution_change', '6', '{\"resolution_id\":4}', NULL, NULL, '{\"change_type\":\"appoint\"}', '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('68', '3', 'Malcom Kintu', 'resolution_applied', 'resolution', '4', NULL, NULL, NULL, NULL, '2026-08-13 19:50:19');
INSERT INTO `audit_log` VALUES ('69', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:50:26');
INSERT INTO `audit_log` VALUES ('70', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:50:37');
INSERT INTO `audit_log` VALUES ('71', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:52:22');
INSERT INTO `audit_log` VALUES ('72', '7', 'Alice Aine', 'register', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-13 19:53:04');
INSERT INTO `audit_log` VALUES ('73', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:53:30');
INSERT INTO `audit_log` VALUES ('74', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:53:44');
INSERT INTO `audit_log` VALUES ('75', '1', 'System Admin', 'cap_assign', 'role', '6', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:53:44');
INSERT INTO `audit_log` VALUES ('76', '1', 'System Admin', 'cap_assign', 'role', '6', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:53:44');
INSERT INTO `audit_log` VALUES ('77', '1', 'System Admin', 'cap_assign', 'role', '6', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:53:44');
INSERT INTO `audit_log` VALUES ('78', '1', 'System Admin', 'cap_assign', 'role', '6', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:53:44');
INSERT INTO `audit_log` VALUES ('79', '1', 'System Admin', 'role_create', 'role', '6', NULL, NULL, NULL, '{\"title\":\"Member\",\"capabilities\":[1,7,27,34]}', '2026-08-13 19:53:44');
INSERT INTO `audit_log` VALUES ('80', '1', 'System Admin', 'role_assign', 'role', '6', NULL, NULL, NULL, '{\"user_id\":7,\"assigned_by\":1}', '2026-08-13 19:53:44');
INSERT INTO `audit_log` VALUES ('81', '1', 'System Admin', 'member_approve', 'member', '7', NULL, NULL, NULL, '{\"approved_by\":1,\"status\":\"active\"}', '2026-08-13 19:53:44');
INSERT INTO `audit_log` VALUES ('82', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-13 19:53:44');
INSERT INTO `audit_log` VALUES ('83', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-13 19:53:51');
INSERT INTO `audit_log` VALUES ('84', '7', 'Alice Aine', 'article_create', 'article', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:53:51');
INSERT INTO `audit_log` VALUES ('85', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-13 19:53:51');
INSERT INTO `audit_log` VALUES ('86', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-13 19:54:11');
INSERT INTO `audit_log` VALUES ('87', '7', 'Alice Aine', 'workflow_transition', 'article', '2', NULL, NULL, NULL, '{\"from\":\"draft\",\"to\":\"submitted\",\"user_id\":7}', '2026-08-13 19:54:11');
INSERT INTO `audit_log` VALUES ('88', '7', 'Alice Aine', 'article_create', 'article', '2', NULL, NULL, NULL, NULL, '2026-08-13 19:54:11');
INSERT INTO `audit_log` VALUES ('89', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-13 19:54:11');
INSERT INTO `audit_log` VALUES ('90', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-13 19:54:43');
INSERT INTO `audit_log` VALUES ('91', '4', 'John Mukasa', 'workflow_transition', 'article', '2', NULL, NULL, NULL, '{\"from\":\"under_review\",\"to\":\"approved\",\"user_id\":4}', '2026-08-13 19:54:43');
INSERT INTO `audit_log` VALUES ('92', '4', 'John Mukasa', 'workflow_transition', 'article', '2', NULL, NULL, NULL, '{\"from\":\"approved\",\"to\":\"published\",\"user_id\":4}', '2026-08-13 19:54:43');
INSERT INTO `audit_log` VALUES ('93', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-13 19:55:33');
INSERT INTO `audit_log` VALUES ('94', '7', 'Alice Aine', 'workflow_transition', 'event', '1', NULL, NULL, NULL, '{\"from\":\"draft\",\"to\":\"submitted\",\"user_id\":7}', '2026-08-13 19:55:34');
INSERT INTO `audit_log` VALUES ('95', '7', 'Alice Aine', 'event_create', 'event', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:55:34');
INSERT INTO `audit_log` VALUES ('96', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-13 19:55:34');
INSERT INTO `audit_log` VALUES ('97', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-13 19:55:45');
INSERT INTO `audit_log` VALUES ('98', '2', 'Cosmus Ngabirano', 'workflow_transition', 'event', '1', NULL, NULL, NULL, '{\"from\":\"submitted\",\"to\":\"approved\",\"user_id\":2}', '2026-08-13 19:55:45');
INSERT INTO `audit_log` VALUES ('99', '2', 'Cosmus Ngabirano', 'workflow_transition', 'event', '1', NULL, NULL, NULL, '{\"from\":\"approved\",\"to\":\"published\",\"user_id\":2}', '2026-08-13 19:55:45');
INSERT INTO `audit_log` VALUES ('100', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-13 19:57:03');
INSERT INTO `audit_log` VALUES ('101', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('102', '3', 'Malcom Kintu', 'login', 'user', '3', NULL, NULL, NULL, NULL, '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('103', '1', 'System Admin', 'resolution_create', 'resolution', '5', NULL, NULL, NULL, '{\"code\":\"UAS-BRD-2026-003\",\"type\":\"role_create\",\"proposed_by\":1}', '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('104', '1', 'System Admin', 'resolution_submit', 'resolution', '5', NULL, NULL, NULL, NULL, '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('105', '1', 'System Admin', 'resolution_voting', 'resolution', '5', NULL, NULL, NULL, NULL, '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('106', '1', 'System Admin', 'resolution_vote', 'resolution', '5', NULL, NULL, NULL, '{\"user_id\":1,\"value\":\"for\"}', '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('107', '2', 'Cosmus Ngabirano', 'resolution_vote', 'resolution', '5', NULL, NULL, NULL, '{\"user_id\":2,\"value\":\"for\"}', '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('108', '3', 'Malcom Kintu', 'resolution_vote', 'resolution', '5', NULL, NULL, NULL, '{\"user_id\":3,\"value\":\"for\"}', '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('109', '3', 'Malcom Kintu', 'resolution_passed', 'resolution', '5', NULL, NULL, NULL, NULL, '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('110', '3', 'Malcom Kintu', 'cap_assign', 'role', '7', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('111', '3', 'Malcom Kintu', 'cap_assign', 'role', '7', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('112', '3', 'Malcom Kintu', 'cap_assign', 'role', '7', NULL, NULL, NULL, '{\"granted_by\":1}', '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('113', '3', 'Malcom Kintu', 'role_create', 'role', '7', '{\"resolution_id\":5}', NULL, NULL, '{\"title\":\"Outreach Coordinator\",\"capabilities\":[\"events.approve\",\"events.publish\",\"articles.approve\"]}', '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('114', '3', 'Malcom Kintu', 'resolution_change_applied', 'resolution_change', '7', '{\"resolution_id\":5}', NULL, NULL, '{\"change_type\":\"role_create\"}', '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('115', '3', 'Malcom Kintu', 'resolution_applied', 'resolution', '5', NULL, NULL, NULL, NULL, '2026-08-13 19:57:04');
INSERT INTO `audit_log` VALUES ('116', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 09:40:40');
INSERT INTO `audit_log` VALUES ('117', '7', 'Alice Aine', 'workflow_transition', 'document', '1', NULL, NULL, NULL, '{\"from\":\"draft\",\"to\":\"submitted\",\"user_id\":7}', '2026-08-14 09:40:40');
INSERT INTO `audit_log` VALUES ('118', '7', 'Alice Aine', 'document_upload', 'document', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:40:40');
INSERT INTO `audit_log` VALUES ('119', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-14 09:40:41');
INSERT INTO `audit_log` VALUES ('120', '2', 'Cosmus Ngabirano', 'workflow_transition', 'document', '1', NULL, NULL, NULL, '{\"from\":\"submitted\",\"to\":\"approved\",\"user_id\":2}', '2026-08-14 09:40:41');
INSERT INTO `audit_log` VALUES ('121', '2', 'Cosmus Ngabirano', 'workflow_transition', 'document', '1', NULL, NULL, NULL, '{\"from\":\"approved\",\"to\":\"published\",\"user_id\":2}', '2026-08-14 09:40:41');
INSERT INTO `audit_log` VALUES ('122', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-14 09:40:47');
INSERT INTO `audit_log` VALUES ('123', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-14 09:40:52');
INSERT INTO `audit_log` VALUES ('124', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-14 09:42:34');
INSERT INTO `audit_log` VALUES ('125', '2', 'Cosmus Ngabirano', 'finance_record', 'financial_record', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:42:34');
INSERT INTO `audit_log` VALUES ('126', '2', 'Cosmus Ngabirano', 'finance_record', 'financial_record', '2', NULL, NULL, NULL, NULL, '2026-08-14 09:42:34');
INSERT INTO `audit_log` VALUES ('127', '2', 'Cosmus Ngabirano', 'assignment_create', 'assignment', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:42:35');
INSERT INTO `audit_log` VALUES ('128', '2', 'Cosmus Ngabirano', 'calendar_create', 'calendar_item', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:42:35');
INSERT INTO `audit_log` VALUES ('129', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 09:42:35');
INSERT INTO `audit_log` VALUES ('130', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-14 09:42:44');
INSERT INTO `audit_log` VALUES ('131', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:45:21');
INSERT INTO `audit_log` VALUES ('132', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 09:45:21');
INSERT INTO `audit_log` VALUES ('133', '4', 'John Mukasa', 'project_create', 'project', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:45:21');
INSERT INTO `audit_log` VALUES ('134', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:46:03');
INSERT INTO `audit_log` VALUES ('135', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 09:47:33');
INSERT INTO `audit_log` VALUES ('136', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 09:52:26');
INSERT INTO `audit_log` VALUES ('137', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 09:52:26');
INSERT INTO `audit_log` VALUES ('138', '7', 'Alice Aine', 'event_rsvp', 'event', '1', NULL, NULL, NULL, '{\"user_id\":7}', '2026-08-14 09:52:26');
INSERT INTO `audit_log` VALUES ('139', '4', 'John Mukasa', 'event_rsvp', 'event', '1', NULL, NULL, NULL, '{\"user_id\":4}', '2026-08-14 09:52:26');
INSERT INTO `audit_log` VALUES ('140', '2', 'Cosmus Ngabirano', 'login', 'user', '2', NULL, NULL, NULL, NULL, '2026-08-14 09:52:38');
INSERT INTO `audit_log` VALUES ('141', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 09:52:38');
INSERT INTO `audit_log` VALUES ('142', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 09:52:50');
INSERT INTO `audit_log` VALUES ('143', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 09:52:50');
INSERT INTO `audit_log` VALUES ('144', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 09:52:50');
INSERT INTO `audit_log` VALUES ('145', '7', 'Alice Aine', 'event_rsvp_cancel', 'event', '1', NULL, NULL, NULL, '{\"user_id\":7}', '2026-08-14 09:52:50');
INSERT INTO `audit_log` VALUES ('146', '7', 'Alice Aine', 'event_rsvp_cancel', 'event', '1', NULL, NULL, NULL, '{\"user_id\":7}', '2026-08-14 09:52:50');
INSERT INTO `audit_log` VALUES ('147', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:57:06');
INSERT INTO `audit_log` VALUES ('148', '1', 'System Admin', 'partner_create', 'partner', '2', NULL, NULL, NULL, NULL, '2026-08-14 09:57:06');
INSERT INTO `audit_log` VALUES ('149', '1', 'System Admin', 'link_create', 'link', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:57:06');
INSERT INTO `audit_log` VALUES ('150', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 09:57:06');
INSERT INTO `audit_log` VALUES ('151', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:57:14');
INSERT INTO `audit_log` VALUES ('152', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:57:21');
INSERT INTO `audit_log` VALUES ('153', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 09:57:21');
INSERT INTO `audit_log` VALUES ('154', '1', 'System Admin', 'partner_deactivate', 'partner', '2', NULL, NULL, NULL, NULL, '2026-08-14 09:57:21');
INSERT INTO `audit_log` VALUES ('155', '1', 'System Admin', 'link_deactivate', 'link', '1', NULL, NULL, NULL, NULL, '2026-08-14 09:57:21');
INSERT INTO `audit_log` VALUES ('156', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 10:22:33');
INSERT INTO `audit_log` VALUES ('157', '7', 'Alice Aine', 'profile_update', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 10:22:33');
INSERT INTO `audit_log` VALUES ('158', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 10:22:40');
INSERT INTO `audit_log` VALUES ('159', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 11:32:09');
INSERT INTO `audit_log` VALUES ('160', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 11:32:10');
INSERT INTO `audit_log` VALUES ('161', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 11:32:33');
INSERT INTO `audit_log` VALUES ('162', '7', 'Alice Aine', 'password_change', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 11:32:34');
INSERT INTO `audit_log` VALUES ('163', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 11:32:34');
INSERT INTO `audit_log` VALUES ('164', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 11:32:40');
INSERT INTO `audit_log` VALUES ('165', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 11:32:41');
INSERT INTO `audit_log` VALUES ('166', '4', 'John Mukasa', 'assignment_create', 'assignment', '2', NULL, NULL, NULL, NULL, '2026-08-14 11:32:41');
INSERT INTO `audit_log` VALUES ('167', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 11:32:51');
INSERT INTO `audit_log` VALUES ('168', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 11:32:51');
INSERT INTO `audit_log` VALUES ('169', '7', 'Alice Aine', 'assignment_start', 'assignment', '2', NULL, NULL, NULL, NULL, '2026-08-14 11:32:51');
INSERT INTO `audit_log` VALUES ('170', '7', 'Alice Aine', 'assignment_submit', 'assignment', '2', NULL, NULL, NULL, NULL, '2026-08-14 11:32:51');
INSERT INTO `audit_log` VALUES ('171', '4', 'John Mukasa', 'assignment_complete', 'assignment', '2', NULL, NULL, NULL, NULL, '2026-08-14 11:32:51');
INSERT INTO `audit_log` VALUES ('172', NULL, NULL, 'resolution_create', 'resolution', '6', NULL, NULL, NULL, '{\"code\":\"UAS-BRD-2026-004\",\"type\":\"role_create\",\"proposed_by\":2}', '2026-08-14 13:19:24');
INSERT INTO `audit_log` VALUES ('173', NULL, NULL, 'resolution_vote', 'resolution', '6', NULL, NULL, NULL, '{\"user_id\":2,\"value\":\"for\"}', '2026-08-14 13:20:39');
INSERT INTO `audit_log` VALUES ('174', NULL, NULL, 'resolution_create', 'resolution', '7', NULL, NULL, NULL, '{\"code\":\"UAS-BRD-2026-004\",\"type\":\"role_create\",\"proposed_by\":2}', '2026-08-14 13:21:05');
INSERT INTO `audit_log` VALUES ('175', NULL, NULL, 'resolution_vote', 'resolution', '7', NULL, NULL, NULL, '{\"user_id\":2,\"value\":\"for\"}', '2026-08-14 13:21:05');
INSERT INTO `audit_log` VALUES ('176', NULL, NULL, 'resolution_vote', 'resolution', '7', NULL, NULL, NULL, '{\"user_id\":3,\"value\":\"for\"}', '2026-08-14 13:21:05');
INSERT INTO `audit_log` VALUES ('177', NULL, NULL, 'resolution_vote', 'resolution', '7', NULL, NULL, NULL, '{\"user_id\":4,\"value\":\"for\"}', '2026-08-14 13:21:05');
INSERT INTO `audit_log` VALUES ('178', NULL, NULL, 'resolution_passed', 'resolution', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:21:05');
INSERT INTO `audit_log` VALUES ('179', NULL, NULL, 'role_create', 'role', '8', '{\"resolution_id\":7}', NULL, NULL, '{\"title\":\"Outreach Coordinator\",\"capabilities\":[]}', '2026-08-14 13:21:05');
INSERT INTO `audit_log` VALUES ('180', NULL, NULL, 'resolution_change_applied', 'resolution_change', '10', '{\"resolution_id\":7}', NULL, NULL, '{\"change_type\":\"role_create\"}', '2026-08-14 13:21:05');
INSERT INTO `audit_log` VALUES ('181', NULL, NULL, 'resolution_change_applied', 'resolution_change', '11', '{\"resolution_id\":7}', NULL, NULL, '{\"change_type\":\"appoint\"}', '2026-08-14 13:21:05');
INSERT INTO `audit_log` VALUES ('182', NULL, NULL, 'resolution_applied', 'resolution', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:21:05');
INSERT INTO `audit_log` VALUES ('183', NULL, NULL, 'resolution_create', 'resolution', '8', NULL, NULL, NULL, '{\"code\":\"UAS-BRD-2026-005\",\"type\":\"role_create\",\"proposed_by\":2}', '2026-08-14 13:21:35');
INSERT INTO `audit_log` VALUES ('184', NULL, NULL, 'resolution_vote', 'resolution', '8', NULL, NULL, NULL, '{\"user_id\":2,\"value\":\"for\"}', '2026-08-14 13:21:35');
INSERT INTO `audit_log` VALUES ('185', NULL, NULL, 'resolution_vote', 'resolution', '8', NULL, NULL, NULL, '{\"user_id\":3,\"value\":\"for\"}', '2026-08-14 13:21:35');
INSERT INTO `audit_log` VALUES ('186', NULL, NULL, 'resolution_vote', 'resolution', '8', NULL, NULL, NULL, '{\"user_id\":4,\"value\":\"for\"}', '2026-08-14 13:21:35');
INSERT INTO `audit_log` VALUES ('187', NULL, NULL, 'resolution_passed', 'resolution', '8', NULL, NULL, NULL, NULL, '2026-08-14 13:21:35');
INSERT INTO `audit_log` VALUES ('188', NULL, NULL, 'role_create', 'role', '9', '{\"resolution_id\":8}', NULL, NULL, '{\"title\":\"Communications Officer\",\"capabilities\":[]}', '2026-08-14 13:21:35');
INSERT INTO `audit_log` VALUES ('189', NULL, NULL, 'resolution_change_applied', 'resolution_change', '12', '{\"resolution_id\":8}', NULL, NULL, '{\"change_type\":\"role_create\"}', '2026-08-14 13:21:35');
INSERT INTO `audit_log` VALUES ('190', NULL, NULL, 'resolution_change_applied', 'resolution_change', '13', '{\"resolution_id\":8}', NULL, NULL, '{\"change_type\":\"appoint\"}', '2026-08-14 13:21:35');
INSERT INTO `audit_log` VALUES ('191', NULL, NULL, 'resolution_applied', 'resolution', '8', NULL, NULL, NULL, NULL, '2026-08-14 13:21:35');
INSERT INTO `audit_log` VALUES ('192', NULL, NULL, 'resolution_create', 'resolution', '9', NULL, NULL, NULL, '{\"code\":\"UAS-BRD-2026-005\",\"type\":\"role_create\",\"proposed_by\":2}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('193', NULL, NULL, 'resolution_vote', 'resolution', '9', NULL, NULL, NULL, '{\"user_id\":2,\"value\":\"for\"}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('194', NULL, NULL, 'resolution_vote', 'resolution', '9', NULL, NULL, NULL, '{\"user_id\":3,\"value\":\"for\"}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('195', NULL, NULL, 'resolution_vote', 'resolution', '9', NULL, NULL, NULL, '{\"user_id\":4,\"value\":\"for\"}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('196', NULL, NULL, 'resolution_passed', 'resolution', '9', NULL, NULL, NULL, NULL, '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('197', NULL, NULL, 'cap_assign', 'role', '10', NULL, NULL, NULL, '{\"granted_by\":2}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('198', NULL, NULL, 'cap_assign', 'role', '10', NULL, NULL, NULL, '{\"granted_by\":2}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('199', NULL, NULL, 'cap_assign', 'role', '10', NULL, NULL, NULL, '{\"granted_by\":2}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('200', NULL, NULL, 'cap_assign', 'role', '10', NULL, NULL, NULL, '{\"granted_by\":2}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('201', NULL, NULL, 'role_create', 'role', '10', '{\"resolution_id\":9}', NULL, NULL, '{\"title\":\"Communications Officer\",\"capabilities\":[\"articles.submit\",\"articles.review\",\"events.create\",\"events.rsvp\"]}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('202', NULL, NULL, 'resolution_change_applied', 'resolution_change', '14', '{\"resolution_id\":9}', NULL, NULL, '{\"change_type\":\"role_create\"}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('203', NULL, NULL, 'role_assign', 'role', '10', '{\"resolution_id\":9}', NULL, NULL, '{\"user_id\":9,\"assigned_by\":2}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('204', NULL, NULL, 'resolution_change_applied', 'resolution_change', '15', '{\"resolution_id\":9}', NULL, NULL, '{\"change_type\":\"appoint\"}', '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('205', NULL, NULL, 'resolution_applied', 'resolution', '9', NULL, NULL, NULL, NULL, '2026-08-14 13:22:22');
INSERT INTO `audit_log` VALUES ('206', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:22:49');
INSERT INTO `audit_log` VALUES ('207', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 13:22:50');
INSERT INTO `audit_log` VALUES ('208', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:22:50');
INSERT INTO `audit_log` VALUES ('209', '9', 'Grace Achieng', 'login', 'user', '9', NULL, NULL, NULL, NULL, '2026-08-14 13:22:50');
INSERT INTO `audit_log` VALUES ('210', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:23:07');
INSERT INTO `audit_log` VALUES ('211', '9', 'Grace Achieng', 'login', 'user', '9', NULL, NULL, NULL, NULL, '2026-08-14 13:23:07');
INSERT INTO `audit_log` VALUES ('212', '9', 'Grace Achieng', 'workflow_transition', 'article', '7', NULL, NULL, NULL, '{\"from\":\"draft\",\"to\":\"submitted\",\"user_id\":9}', '2026-08-14 13:23:07');
INSERT INTO `audit_log` VALUES ('213', '9', 'Grace Achieng', 'article_create', 'article', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:23:07');
INSERT INTO `audit_log` VALUES ('214', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:23:13');
INSERT INTO `audit_log` VALUES ('215', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:23:30');
INSERT INTO `audit_log` VALUES ('216', '1', 'System Admin', 'workflow_transition', 'article', '7', NULL, NULL, NULL, '{\"from\":\"under_review\",\"to\":\"approved\",\"user_id\":1}', '2026-08-14 13:23:30');
INSERT INTO `audit_log` VALUES ('217', '1', 'System Admin', 'workflow_transition', 'article', '7', NULL, NULL, NULL, '{\"from\":\"approved\",\"to\":\"published\",\"user_id\":1}', '2026-08-14 13:23:30');
INSERT INTO `audit_log` VALUES ('218', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:35:22');
INSERT INTO `audit_log` VALUES ('219', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:35:22');
INSERT INTO `audit_log` VALUES ('220', '7', 'Alice Aine', 'workflow_transition', 'article', '8', NULL, NULL, NULL, '{\"from\":\"draft\",\"to\":\"submitted\",\"user_id\":7}', '2026-08-14 13:35:22');
INSERT INTO `audit_log` VALUES ('221', '7', 'Alice Aine', 'article_create', 'article', '8', NULL, NULL, NULL, NULL, '2026-08-14 13:35:22');
INSERT INTO `audit_log` VALUES ('222', '1', 'System Admin', 'article_reject', 'article', '8', NULL, NULL, NULL, '{\"reason\":\"Duplicate of existing plan; revise and resubmit\"}', '2026-08-14 13:35:22');
INSERT INTO `audit_log` VALUES ('223', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:35:31');
INSERT INTO `audit_log` VALUES ('224', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:35:31');
INSERT INTO `audit_log` VALUES ('225', '1', 'System Admin', 'event_cancel', 'event', '2', NULL, NULL, NULL, NULL, '2026-08-14 13:35:31');
INSERT INTO `audit_log` VALUES ('226', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 13:35:31');
INSERT INTO `audit_log` VALUES ('227', '1', 'System Admin', 'rsvp_mark_attended', 'event', '1', NULL, NULL, NULL, '{\"registration_id\":2}', '2026-08-14 13:35:31');
INSERT INTO `audit_log` VALUES ('228', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:35:44');
INSERT INTO `audit_log` VALUES ('229', '7', 'Alice Aine', 'event_rsvp', 'event', '1', NULL, NULL, NULL, '{\"user_id\":7}', '2026-08-14 13:35:44');
INSERT INTO `audit_log` VALUES ('230', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:35:44');
INSERT INTO `audit_log` VALUES ('231', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:50:20');
INSERT INTO `audit_log` VALUES ('232', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:50:20');
INSERT INTO `audit_log` VALUES ('233', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:55:01');
INSERT INTO `audit_log` VALUES ('234', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:55:16');
INSERT INTO `audit_log` VALUES ('235', '9', 'Grace Achieng', 'login', 'user', '9', NULL, NULL, NULL, NULL, '2026-08-14 13:55:16');
INSERT INTO `audit_log` VALUES ('236', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:55:47');
INSERT INTO `audit_log` VALUES ('237', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:55:47');
INSERT INTO `audit_log` VALUES ('238', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:56:08');
INSERT INTO `audit_log` VALUES ('239', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:56:08');
INSERT INTO `audit_log` VALUES ('240', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:56:23');
INSERT INTO `audit_log` VALUES ('241', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:56:23');
INSERT INTO `audit_log` VALUES ('242', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:56:33');
INSERT INTO `audit_log` VALUES ('243', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:56:33');
INSERT INTO `audit_log` VALUES ('244', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:57:40');
INSERT INTO `audit_log` VALUES ('245', '9', 'Grace Achieng', 'login', 'user', '9', NULL, NULL, NULL, NULL, '2026-08-14 13:57:40');
INSERT INTO `audit_log` VALUES ('246', '1', 'System Admin', 'member_password_reset', 'user', '3', NULL, NULL, NULL, '{\"by\":1}', '2026-08-14 13:57:40');
INSERT INTO `audit_log` VALUES ('247', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:57:40');
INSERT INTO `audit_log` VALUES ('248', '1', 'System Admin', 'member_password_reset', 'user', '3', NULL, NULL, NULL, '{\"by\":1}', '2026-08-14 13:57:40');
INSERT INTO `audit_log` VALUES ('249', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:57:50');
INSERT INTO `audit_log` VALUES ('250', '1', 'System Admin', 'member_password_reset', 'user', '3', NULL, NULL, NULL, '{\"by\":1}', '2026-08-14 13:57:50');
INSERT INTO `audit_log` VALUES ('251', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:57:57');
INSERT INTO `audit_log` VALUES ('252', '1', 'System Admin', 'member_password_reset', 'user', '3', NULL, NULL, NULL, '{\"by\":1}', '2026-08-14 13:57:57');
INSERT INTO `audit_log` VALUES ('253', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:58:02');
INSERT INTO `audit_log` VALUES ('254', '1', 'System Admin', 'member_password_reset', 'user', '8', NULL, NULL, NULL, '{\"by\":1}', '2026-08-14 13:58:03');
INSERT INTO `audit_log` VALUES ('255', '8', 'Peter Okello', 'login', 'user', '8', NULL, NULL, NULL, NULL, '2026-08-14 13:58:03');
INSERT INTO `audit_log` VALUES ('256', '3', 'Malcom Kintu', 'login', 'user', '3', NULL, NULL, NULL, NULL, '2026-08-14 13:58:03');
INSERT INTO `audit_log` VALUES ('257', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:58:10');
INSERT INTO `audit_log` VALUES ('258', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 13:58:10');
INSERT INTO `audit_log` VALUES ('259', '8', 'Peter Okello', 'login', 'user', '8', NULL, NULL, NULL, NULL, '2026-08-14 13:58:34');
INSERT INTO `audit_log` VALUES ('260', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 13:58:52');
INSERT INTO `audit_log` VALUES ('261', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 14:02:34');
INSERT INTO `audit_log` VALUES ('262', '1', 'System Admin', 'role_assign', 'role', '6', NULL, NULL, NULL, '{\"user_id\":11,\"assigned_by\":1}', '2026-08-14 14:02:34');
INSERT INTO `audit_log` VALUES ('263', '1', 'System Admin', 'role_assign', 'role', '6', NULL, NULL, NULL, '{\"user_id\":12,\"assigned_by\":1}', '2026-08-14 14:02:34');
INSERT INTO `audit_log` VALUES ('264', '1', 'System Admin', 'members_import', 'system', '1', NULL, NULL, NULL, '{\"created\":2,\"skipped\":1}', '2026-08-14 14:02:34');
INSERT INTO `audit_log` VALUES ('265', '11', 'Kato Sarah', 'login', 'user', '11', NULL, NULL, NULL, NULL, '2026-08-14 14:02:35');
INSERT INTO `audit_log` VALUES ('266', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 14:02:35');
INSERT INTO `audit_log` VALUES ('267', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 14:03:25');
INSERT INTO `audit_log` VALUES ('268', '9', 'Grace Achieng', 'login', 'user', '9', NULL, NULL, NULL, NULL, '2026-08-14 15:29:07');
INSERT INTO `audit_log` VALUES ('269', '9', 'Grace Achieng', 'workflow_transition', 'article', '9', NULL, NULL, NULL, '{\"from\":\"draft\",\"to\":\"submitted\",\"user_id\":9}', '2026-08-14 15:29:07');
INSERT INTO `audit_log` VALUES ('270', '9', 'Grace Achieng', 'article_create', 'article', '9', NULL, NULL, NULL, NULL, '2026-08-14 15:29:07');
INSERT INTO `audit_log` VALUES ('271', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 15:36:30');
INSERT INTO `audit_log` VALUES ('272', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 15:36:30');
INSERT INTO `audit_log` VALUES ('273', '5', 'Sarah Namukasa', 'login', 'user', '5', NULL, NULL, NULL, NULL, '2026-08-14 15:36:30');
INSERT INTO `audit_log` VALUES ('274', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 15:36:31');
INSERT INTO `audit_log` VALUES ('275', '4', 'John Mukasa', 'event_rsvp', 'event', '3', NULL, NULL, NULL, '{\"user_id\":4}', '2026-08-14 15:36:31');
INSERT INTO `audit_log` VALUES ('276', '5', 'Sarah Namukasa', 'event_rsvp', 'event', '3', NULL, NULL, NULL, '{\"user_id\":5}', '2026-08-14 15:36:31');
INSERT INTO `audit_log` VALUES ('277', '7', 'Alice Aine', 'waitlist_join', 'event', '3', NULL, NULL, NULL, '{\"user_id\":7}', '2026-08-14 15:36:31');
INSERT INTO `audit_log` VALUES ('278', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 15:36:39');
INSERT INTO `audit_log` VALUES ('279', '4', 'John Mukasa', 'login', 'user', '4', NULL, NULL, NULL, NULL, '2026-08-14 15:36:39');
INSERT INTO `audit_log` VALUES ('280', '5', 'Sarah Namukasa', 'login', 'user', '5', NULL, NULL, NULL, NULL, '2026-08-14 15:36:39');
INSERT INTO `audit_log` VALUES ('281', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 15:36:39');
INSERT INTO `audit_log` VALUES ('282', '5', 'Sarah Namukasa', 'event_rsvp_cancel', 'event', '3', NULL, NULL, NULL, '{\"user_id\":5}', '2026-08-14 15:36:39');
INSERT INTO `audit_log` VALUES ('283', '5', 'Sarah Namukasa', 'waitlist_promote', 'event', '3', NULL, NULL, NULL, '{\"user_id\":7}', '2026-08-14 15:36:39');
INSERT INTO `audit_log` VALUES ('284', '4', 'John Mukasa', 'event_rsvp_cancel', 'event', '3', NULL, NULL, NULL, '{\"user_id\":4}', '2026-08-14 15:36:39');
INSERT INTO `audit_log` VALUES ('285', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 15:36:50');
INSERT INTO `audit_log` VALUES ('286', '5', 'Sarah Namukasa', 'login', 'user', '5', NULL, NULL, NULL, NULL, '2026-08-14 15:36:50');
INSERT INTO `audit_log` VALUES ('287', '8', 'Peter Okello', 'login', 'user', '8', NULL, NULL, NULL, NULL, '2026-08-14 15:36:50');
INSERT INTO `audit_log` VALUES ('288', '5', 'Sarah Namukasa', 'event_rsvp', 'event', '3', NULL, NULL, NULL, '{\"user_id\":5}', '2026-08-14 15:36:50');
INSERT INTO `audit_log` VALUES ('289', '8', 'Peter Okello', 'waitlist_join', 'event', '3', NULL, NULL, NULL, '{\"user_id\":8}', '2026-08-14 15:36:50');
INSERT INTO `audit_log` VALUES ('290', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 15:36:50');
INSERT INTO `audit_log` VALUES ('291', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 15:37:10');
INSERT INTO `audit_log` VALUES ('292', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 15:37:30');
INSERT INTO `audit_log` VALUES ('293', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 15:37:30');
INSERT INTO `audit_log` VALUES ('294', '7', 'Alice Aine', 'event_rsvp_cancel', 'event', '3', NULL, NULL, NULL, '{\"user_id\":7}', '2026-08-14 15:37:30');
INSERT INTO `audit_log` VALUES ('295', '1', 'System Admin', 'waitlist_promote', 'event', '3', NULL, NULL, NULL, '{\"user_id\":8}', '2026-08-14 15:37:32');
INSERT INTO `audit_log` VALUES ('296', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 15:39:03');
INSERT INTO `audit_log` VALUES ('297', '8', 'Peter Okello', 'login', 'user', '8', NULL, NULL, NULL, NULL, '2026-08-14 15:39:03');
INSERT INTO `audit_log` VALUES ('298', '10', 'Dr. Ronald Kiiza', 'login', 'user', '10', NULL, NULL, NULL, NULL, '2026-08-14 15:39:04');
INSERT INTO `audit_log` VALUES ('299', '10', 'Dr. Ronald Kiiza', 'waitlist_join', 'event', '3', NULL, NULL, NULL, '{\"user_id\":10}', '2026-08-14 15:39:04');
INSERT INTO `audit_log` VALUES ('300', '8', 'Peter Okello', 'event_rsvp_cancel', 'event', '3', NULL, NULL, NULL, '{\"user_id\":8}', '2026-08-14 15:39:04');
INSERT INTO `audit_log` VALUES ('301', '8', 'Peter Okello', 'waitlist_promote', 'event', '3', NULL, NULL, NULL, '{\"user_id\":10}', '2026-08-14 15:39:04');
INSERT INTO `audit_log` VALUES ('302', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 15:59:24');
INSERT INTO `audit_log` VALUES ('303', '9', 'Grace Achieng', 'login', 'user', '9', NULL, NULL, NULL, NULL, '2026-08-14 15:59:25');
INSERT INTO `audit_log` VALUES ('304', '9', 'Grace Achieng', 'workflow_transition', 'article', '10', NULL, NULL, NULL, '{\"from\":\"draft\",\"to\":\"submitted\",\"user_id\":9}', '2026-08-14 15:59:25');
INSERT INTO `audit_log` VALUES ('305', '9', 'Grace Achieng', 'article_create', 'article', '10', NULL, NULL, NULL, NULL, '2026-08-14 15:59:25');
INSERT INTO `audit_log` VALUES ('306', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 15:59:55');
INSERT INTO `audit_log` VALUES ('307', '9', 'Grace Achieng', 'login', 'user', '9', NULL, NULL, NULL, NULL, '2026-08-14 15:59:56');
INSERT INTO `audit_log` VALUES ('308', '1', 'System Admin', 'workflow_transition', 'article', '10', NULL, NULL, NULL, '{\"from\":\"under_review\",\"to\":\"approved\",\"user_id\":1}', '2026-08-14 15:59:56');
INSERT INTO `audit_log` VALUES ('309', '1', 'System Admin', 'workflow_transition', 'article', '10', NULL, NULL, NULL, '{\"from\":\"approved\",\"to\":\"published\",\"user_id\":1}', '2026-08-14 15:59:56');
INSERT INTO `audit_log` VALUES ('310', '9', 'Grace Achieng', 'workflow_transition', 'event', '6', NULL, NULL, NULL, '{\"from\":\"draft\",\"to\":\"submitted\",\"user_id\":9}', '2026-08-14 15:59:56');
INSERT INTO `audit_log` VALUES ('311', '9', 'Grace Achieng', 'event_create', 'event', '6', NULL, NULL, NULL, NULL, '2026-08-14 15:59:56');
INSERT INTO `audit_log` VALUES ('312', '1', 'System Admin', 'workflow_transition', 'event', '6', NULL, NULL, NULL, '{\"from\":\"submitted\",\"to\":\"approved\",\"user_id\":1}', '2026-08-14 15:59:56');
INSERT INTO `audit_log` VALUES ('313', '1', 'System Admin', 'workflow_transition', 'event', '6', NULL, NULL, NULL, '{\"from\":\"approved\",\"to\":\"published\",\"user_id\":1}', '2026-08-14 15:59:56');
INSERT INTO `audit_log` VALUES ('314', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 16:00:08');
INSERT INTO `audit_log` VALUES ('315', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 16:00:08');
INSERT INTO `audit_log` VALUES ('316', '1', 'System Admin', 'assignment_create', 'assignment', '6', NULL, NULL, NULL, NULL, '2026-08-14 16:00:09');
INSERT INTO `audit_log` VALUES ('317', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-14 16:00:22');
INSERT INTO `audit_log` VALUES ('318', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-14 16:00:23');
INSERT INTO `audit_log` VALUES ('319', '1', 'System Admin', 'assignment_create', 'assignment', '7', NULL, NULL, NULL, NULL, '2026-08-14 16:00:23');
INSERT INTO `audit_log` VALUES ('320', '8', 'Peter Okello', 'login', 'user', '8', NULL, NULL, NULL, NULL, '2026-08-14 16:00:31');
INSERT INTO `audit_log` VALUES ('321', '10', 'Dr. Ronald Kiiza', 'login', 'user', '10', NULL, NULL, NULL, NULL, '2026-08-14 16:00:31');
INSERT INTO `audit_log` VALUES ('322', '8', 'Peter Okello', 'event_rsvp_cancel', 'event', '3', NULL, NULL, NULL, '{\"user_id\":8}', '2026-08-14 16:00:31');
INSERT INTO `audit_log` VALUES ('323', '10', 'Dr. Ronald Kiiza', 'login', 'user', '10', NULL, NULL, NULL, NULL, '2026-08-14 16:00:44');
INSERT INTO `audit_log` VALUES ('324', '9', 'Grace Achieng', 'login', 'user', '9', NULL, NULL, NULL, NULL, '2026-08-14 16:00:45');
INSERT INTO `audit_log` VALUES ('325', '9', 'Grace Achieng', 'waitlist_join', 'event', '3', NULL, NULL, NULL, '{\"user_id\":9}', '2026-08-14 16:00:45');
INSERT INTO `audit_log` VALUES ('326', '10', 'Dr. Ronald Kiiza', 'event_rsvp_cancel', 'event', '3', NULL, NULL, NULL, '{\"user_id\":10}', '2026-08-14 16:00:45');
INSERT INTO `audit_log` VALUES ('327', '10', 'Dr. Ronald Kiiza', 'waitlist_promote', 'event', '3', NULL, NULL, NULL, '{\"user_id\":9}', '2026-08-14 16:00:45');
INSERT INTO `audit_log` VALUES ('328', NULL, NULL, 'role_assign', 'role', '4', NULL, NULL, NULL, '{\"user_id\":13,\"assigned_by\":1}', '2026-08-18 09:34:25');
INSERT INTO `audit_log` VALUES ('329', NULL, NULL, 'role_assign', 'role', '6', NULL, NULL, NULL, '{\"user_id\":13,\"assigned_by\":1}', '2026-08-18 09:34:25');
INSERT INTO `audit_log` VALUES ('330', NULL, NULL, 'role_assign', 'role', '10', NULL, NULL, NULL, '{\"user_id\":14,\"assigned_by\":1}', '2026-08-18 09:34:25');
INSERT INTO `audit_log` VALUES ('331', NULL, NULL, 'role_assign', 'role', '6', NULL, NULL, NULL, '{\"user_id\":14,\"assigned_by\":1}', '2026-08-18 09:34:25');
INSERT INTO `audit_log` VALUES ('332', NULL, NULL, 'role_assign', 'role', '3', NULL, NULL, NULL, '{\"user_id\":15,\"assigned_by\":1}', '2026-08-18 09:34:25');
INSERT INTO `audit_log` VALUES ('333', NULL, NULL, 'role_assign', 'role', '6', NULL, NULL, NULL, '{\"user_id\":15,\"assigned_by\":1}', '2026-08-18 09:34:25');
INSERT INTO `audit_log` VALUES ('334', NULL, NULL, 'role_assign', 'role', '6', NULL, NULL, NULL, '{\"user_id\":16,\"assigned_by\":1}', '2026-08-18 09:34:25');
INSERT INTO `audit_log` VALUES ('335', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-18 09:35:06');
INSERT INTO `audit_log` VALUES ('336', '13', 'Dr. Patricia Owino', 'login', 'user', '13', NULL, NULL, NULL, NULL, '2026-08-18 09:38:07');
INSERT INTO `audit_log` VALUES ('337', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-18 10:54:33');
INSERT INTO `audit_log` VALUES ('338', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-18 10:54:33');
INSERT INTO `audit_log` VALUES ('339', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-18 10:54:41');
INSERT INTO `audit_log` VALUES ('340', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-18 10:54:58');
INSERT INTO `audit_log` VALUES ('341', '7', 'Alice Aine', 'login', 'user', '7', NULL, NULL, NULL, NULL, '2026-08-18 10:54:58');
INSERT INTO `audit_log` VALUES ('342', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-18 10:55:24');
INSERT INTO `audit_log` VALUES ('343', '1', 'System Admin', 'backup_create', 'backup', '0', NULL, NULL, NULL, '{\"file\":\"uas_platform-20260818-095525.sql.gz\"}', '2026-08-18 10:55:25');
INSERT INTO `audit_log` VALUES ('344', '1', 'System Admin', 'backup_delete', 'backup', '0', NULL, NULL, NULL, '{\"file\":\"uas_platform-20260818-095525.sql.gz\"}', '2026-08-18 10:55:28');
INSERT INTO `audit_log` VALUES ('345', '1', 'System Admin', 'login', 'user', '1', NULL, NULL, NULL, NULL, '2026-08-18 10:57:43');

DROP TABLE IF EXISTS `budget_items`;
CREATE TABLE `budget_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('income','expense') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `category` enum('programme','event','equipment','administration','communications','membership','outreach','donation','grant','sponsorship','training','publication','travel','utilities','other') DEFAULT 'other',
  `programme_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `fiscal_year` year(4) DEFAULT year(curdate()),
  `status` enum('draft','active','closed','cancelled') DEFAULT 'draft',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `programme_id` (`programme_id`),
  KEY `project_id` (`project_id`),
  KEY `event_id` (`event_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `budget_items_ibfk_1` FOREIGN KEY (`programme_id`) REFERENCES `programmes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `budget_items_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `budget_items_ibfk_3` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE SET NULL,
  CONSTRAINT `budget_items_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `budget_items` VALUES ('1', 'School Telescope Equipment', 'Purchase of Dobsonian telescopes for school programme', 'expense', '5000000.00', 'equipment', '1', NULL, NULL, '2026', 'active', '1', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `budget_items` VALUES ('2', 'Teacher Training Workshops', 'Training materials and facilitator fees for teacher bootcamps', 'expense', '2000000.00', 'training', '1', NULL, NULL, '2026', 'active', '1', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `budget_items` VALUES ('3', 'UNESCO Grant Application', 'Pending UNESCO capacity-building grant for astronomy education', 'income', '15000000.00', 'grant', '1', NULL, NULL, '2026', 'active', '1', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `budget_items` VALUES ('4', 'Membership Dues Collection Q3', 'Expected membership dues for Q3 2026', 'income', '3000000.00', 'membership', NULL, NULL, NULL, '2026', 'active', '1', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `budget_items` VALUES ('5', 'Public Observing Night Costs', 'Monthly public observing night logistics and refreshments', 'expense', '800000.00', 'event', '2', NULL, NULL, '2026', 'active', '1', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `budget_items` VALUES ('6', 'Stargazing Event Sponsorship', 'Sponsorship from telecom company for National Stargazing Night', 'income', '2000000.00', 'sponsorship', '2', NULL, NULL, '2026', 'active', '1', '2026-08-18 09:33:55', '2026-08-18 09:33:55');

DROP TABLE IF EXISTS `calendar_items`;
CREATE TABLE `calendar_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `type` enum('event','meeting','deadline','governance','report','election','renewal','milestone','other') NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `deadline` datetime NOT NULL,
  `status` enum('pending','in_progress','completed','overdue','cancelled') DEFAULT 'pending',
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `related_type` varchar(100) DEFAULT NULL,
  `related_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `calendar_items_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `calendar_items` VALUES ('1', 'Board meeting - Q3 review', 'meeting', '2', '2026-09-05 14:00:00', 'pending', 'medium', NULL, NULL, 'Review programmes and budget', '2026-08-14 09:42:35');
INSERT INTO `calendar_items` VALUES ('2', 'Monthly Board Meeting', 'meeting', '1', '2026-09-07 17:00:00', 'pending', 'medium', NULL, NULL, NULL, '2026-08-14 13:18:51');
INSERT INTO `calendar_items` VALUES ('3', 'Membership renewal deadline', 'renewal', '1', '2026-09-30 23:59:00', 'pending', 'medium', NULL, NULL, NULL, '2026-08-14 13:18:51');
INSERT INTO `calendar_items` VALUES ('4', 'Astronomy Week planning milestone', 'milestone', '1', '2026-10-15 12:00:00', 'pending', 'medium', NULL, NULL, NULL, '2026-08-14 13:18:51');

DROP TABLE IF EXISTS `capabilities`;
CREATE TABLE `capabilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `capabilities` VALUES ('1', 'articles.submit', 'Submit Articles', 'Submit articles for review', 'content', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('2', 'articles.edit', 'Edit Articles', 'Edit own submitted articles', 'content', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('3', 'articles.review', 'Review Articles', 'Review submitted articles', 'content', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('4', 'articles.approve', 'Approve Articles', 'Approve articles for publication', 'content', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('5', 'articles.publish', 'Publish Articles', 'Publish approved articles', 'content', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('6', 'articles.delete', 'Delete Articles', 'Delete articles', 'content', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('7', 'events.create', 'Create Events', 'Create events', 'events', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('8', 'events.edit', 'Edit Events', 'Edit events', 'events', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('9', 'events.review', 'Review Events', 'Review submitted events', 'events', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('10', 'events.approve', 'Approve Events', 'Approve events for publication', 'events', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('11', 'events.publish', 'Publish Events', 'Publish approved events', 'events', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('12', 'events.cancel', 'Cancel Events', 'Cancel published events', 'events', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('13', 'programmes.create', 'Create Programmes', 'Create new programmes', 'programmes', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('14', 'programmes.manage', 'Manage Programmes', 'Manage programme details and projects', 'programmes', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('15', 'programmes.approve', 'Approve Programmes', 'Approve programme creation', 'programmes', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('16', 'projects.create', 'Create Projects', 'Create new projects', 'projects', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('17', 'projects.manage', 'Manage Projects', 'Manage project details and tasks', 'projects', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('18', 'projects.approve', 'Approve Projects', 'Approve project creation', 'projects', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('19', 'projects.close', 'Close Projects', 'Close completed projects', 'projects', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('20', 'members.view', 'View Members', 'View member profiles', 'members', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('21', 'members.approve', 'Approve Members', 'Approve membership applications', 'members', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('22', 'members.manage', 'Manage Members', 'Manage member accounts', 'members', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('23', 'resolutions.create', 'Create Resolutions', 'Create governance resolutions', 'governance', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('24', 'resolutions.vote', 'Vote on Resolutions', 'Vote on resolutions', 'governance', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('25', 'resolutions.manage', 'Manage Resolutions', 'Manage resolution lifecycle', 'governance', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('26', 'governance.poll.create', 'Create Governance Polls', 'Create governance polls', 'governance', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('27', 'documents.upload', 'Upload Documents', 'Upload documents', 'documents', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('28', 'documents.review', 'Review Documents', 'Review submitted documents', 'documents', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('29', 'documents.approve', 'Approve Documents', 'Approve documents for publication', 'documents', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('30', 'documents.publish', 'Publish Documents', 'Publish approved documents', 'documents', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('31', 'finance.view', 'View Finance', 'View financial records', 'finance', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('32', 'finance.record', 'Record Finance', 'Record financial transactions', 'finance', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('33', 'finance.approve', 'Approve Finance', 'Approve financial records', 'finance', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('34', 'reports.create', 'Create Reports', 'Create reports', 'reports', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('35', 'reports.review', 'Review Reports', 'Review reports', 'reports', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('36', 'reports.publish', 'Publish Reports', 'Publish reports', 'reports', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('37', 'roles.create', 'Create Roles', 'Create institutional roles', 'admin', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('38', 'roles.manage', 'Manage Roles', 'Manage role assignments', 'admin', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('39', 'admin.system', 'System Administration', 'System configuration and maintenance', 'admin', '2026-08-13 19:18:10');
INSERT INTO `capabilities` VALUES ('40', 'events.rsvp', 'RSVP to Events', 'Register interest/attendance for an event', NULL, '2026-08-14 09:51:07');
INSERT INTO `capabilities` VALUES ('41', 'events.manage_rsvps', 'Manage Event RSVPs', 'View and manage attendee registrations', NULL, '2026-08-14 09:51:07');
INSERT INTO `capabilities` VALUES ('42', 'partners.manage', 'Manage Partners', 'Add and deactivate partners on the ecosystem page', NULL, '2026-08-14 09:56:45');
INSERT INTO `capabilities` VALUES ('43', 'links.manage', 'Manage Links', 'Add and deactivate useful links on the ecosystem page', NULL, '2026-08-14 09:56:45');
INSERT INTO `capabilities` VALUES ('44', 'assignments.manage', 'Manage Assignments', 'Create and complete assignments', NULL, '2026-08-14 11:30:35');
INSERT INTO `capabilities` VALUES ('45', 'calendar.manage', 'Manage Calendar', 'Create and manage calendar items', 'admin', '2026-08-18 09:33:38');
INSERT INTO `capabilities` VALUES ('46', 'assignments.create', 'Create Assignments', 'Create and assign tasks to members', 'admin', '2026-08-18 09:33:38');

DROP TABLE IF EXISTS `contact_messages`;
CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','archived') DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `contact_messages` VALUES ('1', 'Sarah Test', 'sarah.test@gmail.com', 'Membership enquiry', 'Hello, how do I join the society as a student member? What is the annual fee?', 'read', '2026-08-14 13:50:12');
INSERT INTO `contact_messages` VALUES ('2', 'Daniel O.', 'daniel.o@yahoo.com', 'School visit request', 'Our school in Jinja would like a visit from your education team in October. Is that possible?', 'read', '2026-08-14 13:50:12');
INSERT INTO `contact_messages` VALUES ('3', 'Test User', 'test@user.ug', 'Hi', 'Testing the contact form', 'read', '2026-08-14 13:50:19');
INSERT INTO `contact_messages` VALUES ('4', 'Visitor', 'v@x.com', '', 'Hello UAS team, great site!', 'new', '2026-08-14 15:59:25');

DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `file_path` varchar(1000) NOT NULL,
  `category` enum('paper','publication','article','guide','image','constitution','policy','minutes','resolution','report','agreement','financial','other') NOT NULL,
  `visibility` enum('public','internal','restricted') DEFAULT 'public',
  `owner_id` int(11) NOT NULL,
  `version` int(11) DEFAULT 1,
  `status` enum('draft','submitted','approved','published','archived') DEFAULT 'draft',
  `approved_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `owner_id` (`owner_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `documents` VALUES ('1', '2026 Annual Report Draft', '/docs/annual-2026.pdf', 'report', 'public', '7', '1', 'published', NULL, '2026-08-14 09:40:40', '2026-08-14 09:40:41');
INSERT INTO `documents` VALUES ('2', 'UAS Constitution', '/docs/constitution.pdf', 'constitution', 'public', '1', '1', 'published', '1', '2026-08-14 09:55:33', '2026-08-10 10:00:00');
INSERT INTO `documents` VALUES ('3', 'Astronomy Education Toolkit', '/docs/toolkit.pdf', 'guide', 'public', '2', '1', 'published', '1', '2026-08-14 09:55:33', '2026-08-14 09:55:33');
INSERT INTO `documents` VALUES ('4', 'UAS Constitution (2026 Revision)', '/docs/constitution-2026.pdf', 'constitution', 'public', '2', '1', 'published', '2', '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `documents` VALUES ('5', 'Annual Financial Report FY2025/26', '/docs/financial-2025-26.pdf', 'financial', 'internal', '5', '1', 'published', '2', '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `documents` VALUES ('6', 'Board Meeting Minutes — July 2026', '/docs/minutes-2026-07.pdf', 'minutes', 'internal', '4', '1', 'published', '2', '2026-08-14 13:18:22', '2026-08-14 13:18:22');

DROP TABLE IF EXISTS `event_registrations`;
CREATE TABLE `event_registrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('registered','attended','cancelled') DEFAULT 'registered',
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_event_user` (`event_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `event_registrations_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `event_registrations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `event_registrations` VALUES ('1', '1', '7', 'registered', '2026-08-14 13:35:44');
INSERT INTO `event_registrations` VALUES ('2', '1', '4', 'attended', '2026-08-14 09:52:26');
INSERT INTO `event_registrations` VALUES ('3', '3', '4', 'cancelled', '2026-08-14 15:36:31');
INSERT INTO `event_registrations` VALUES ('4', '3', '5', 'registered', '2026-08-14 15:36:50');
INSERT INTO `event_registrations` VALUES ('5', '3', '7', 'cancelled', '2026-08-14 15:36:39');
INSERT INTO `event_registrations` VALUES ('6', '3', '8', 'cancelled', '2026-08-14 15:37:32');
INSERT INTO `event_registrations` VALUES ('7', '3', '10', 'cancelled', '2026-08-14 15:39:04');
INSERT INTO `event_registrations` VALUES ('8', '3', '9', 'registered', '2026-08-14 16:00:45');

DROP TABLE IF EXISTS `event_waitlist`;
CREATE TABLE `event_waitlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wait_event_user` (`event_id`,`user_id`),
  KEY `fk_wl_user` (`user_id`),
  CONSTRAINT `fk_wl_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `programme_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `organizer_id` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `location` varchar(500) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `status` enum('draft','submitted','approved','published','cancelled','completed') DEFAULT 'draft',
  `approval_required` tinyint(1) DEFAULT 1,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `programme_id` (`programme_id`),
  KEY `project_id` (`project_id`),
  KEY `organizer_id` (`organizer_id`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `events_ibfk_1` FOREIGN KEY (`programme_id`) REFERENCES `programmes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `events_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `events_ibfk_3` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `events_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `events_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `events` VALUES ('1', NULL, NULL, 'National Stargazing Night 2026', 'Public observing session at Kololo Airstrip', '7', '2026-10-02 19:00:00', NULL, 'Kololo Airstrip, Kampala', '300', 'published', '1', NULL, NULL, '7', '2026-08-13 19:55:34', '2026-08-14 09:52:38');
INSERT INTO `events` VALUES ('2', NULL, NULL, 'September Public Observing Night', 'Monthly public observing night. Target of the month: Saturn and its rings.', '3', '2026-09-04 19:30:00', '2026-09-04 21:30:00', 'Kololo Airstrip, Kampala', '150', 'cancelled', '1', '3', '2026-08-14 13:18:22', '3', '2026-08-14 13:18:22', '2026-08-14 13:35:31');
INSERT INTO `events` VALUES ('3', NULL, NULL, 'Astronomy Education Workshop: Teachers Bootcamp', 'Hands-on training for secondary school science teachers covering solar system models, spectroscopes, and classroom activities.', '5', '2026-09-19 09:00:00', '2026-09-19 16:00:00', 'Makerere University, Kampala', '0', 'published', '1', '5', '2026-08-14 13:18:22', '5', '2026-08-14 13:18:22', '2026-08-14 16:00:45');
INSERT INTO `events` VALUES ('4', NULL, NULL, 'Uganda Astronomy Week Closing Ceremony', 'Closing ceremony and awards for the national astronomy week.', '2', '2026-08-09 15:00:00', '2026-08-09 18:00:00', 'National Theatre, Kampala', '200', 'completed', '1', '2', '2026-08-14 13:18:22', '2', '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `events` VALUES ('5', NULL, NULL, 'Meteor Shower Watch: Perseids 2026', 'Cancelled due to forecast cloud cover. Join us for the next public night instead.', '2', '2026-08-13 22:00:00', NULL, 'Mbale', '80', 'cancelled', '1', NULL, '2026-08-14 13:18:22', '2', '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `events` VALUES ('7', '1', NULL, 'Astrophotography Workshop', 'A hands-on workshop covering DSLR and smartphone astrophotography techniques. Participants will learn to capture the Milky Way, star trails, and lunar craters. Led by UAS outreach team.', NULL, '2026-09-15 18:00:00', '2026-09-15 21:00:00', 'Kololo Airstrip', '25', 'published', '1', NULL, NULL, '8', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `events` VALUES ('8', '1', NULL, 'Public Telescope Night — Entebbe', 'Bring the family for an evening of telescopic observing at the Entebbe Zoo grounds. Jupiter, Saturn, and the Orion Nebula will be visible.', NULL, '2026-10-03 19:00:00', '2026-10-03 22:00:00', 'Entebbe Zoo Grounds', '80', 'published', '1', NULL, NULL, '12', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `events` VALUES ('9', '1', NULL, 'UAS Annual General Meeting', 'Annual gathering of all UAS members. Agenda includes annual report, elections, and strategic planning for 2027.', NULL, '2026-11-20 09:00:00', '2026-11-20 16:00:00', 'Makerere University, Senate Hall', '120', 'published', '1', NULL, NULL, '1', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `events` VALUES ('10', '3', NULL, 'Deep Sky Observing Marathon', 'A night-long deep sky object observing marathon targeting Messier catalogue objects. Open to experienced observers.', NULL, '2026-10-24 20:00:00', '2026-10-25 06:00:00', 'Murchison Falls National Park', '20', 'published', '1', NULL, NULL, '1', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `events` VALUES ('11', '2', NULL, 'Kids Astronomy Day', 'Fun astronomy activities for children aged 6-14: solar viewing, planetarium show, constellation storytelling, and craft activities.', NULL, '2026-12-14 10:00:00', '2026-12-14 14:00:00', 'Ndere Cultural Centre', '60', 'published', '1', NULL, NULL, '12', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `events` VALUES ('12', '1', NULL, 'International Observe the Moon Night', 'Global event celebrating lunar observation. Join UAS at Kololo for guided moon viewing through telescopes.', NULL, '2026-11-18 18:30:00', '2026-11-18 21:30:00', 'Kololo Airstrip', '40', 'published', '1', NULL, NULL, '7', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `events` VALUES ('13', '2', NULL, 'Exoplanet Detection Workshop', 'Learn how professional and amateur astronomers detect planets orbiting distant stars using transit photometry.', NULL, '2026-12-05 14:00:00', '2026-12-05 17:00:00', 'Makerere University, Physics Dept', '30', 'published', '1', NULL, NULL, '3', '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `events` VALUES ('14', '3', NULL, 'Galaxy Season Star Party', 'A multi-night observing event targeting galaxies in the Virgo Cluster. Camping available on site.', NULL, '2027-03-14 18:00:00', '2027-03-15 06:00:00', 'Lake Mburo National Park', '25', 'published', '1', NULL, NULL, '1', '2026-08-18 09:33:55', '2026-08-18 09:33:55');

DROP TABLE IF EXISTS `financial_records`;
CREATE TABLE `financial_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('income','expense','commitment','payable','receivable','budget_item') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `category` enum('programme','event','equipment','administration','communications','membership','outreach','donation','grant','sponsorship','training','publication','travel','utilities','other') DEFAULT 'other',
  `programme_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `budget_item_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `recorded_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `record_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('draft','pending','approved','paid','cancelled') DEFAULT 'approved',
  `attachment_url` varchar(500) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `programme_id` (`programme_id`),
  KEY `project_id` (`project_id`),
  KEY `recorded_by` (`recorded_by`),
  KEY `approved_by` (`approved_by`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `financial_records_ibfk_1` FOREIGN KEY (`programme_id`) REFERENCES `programmes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `financial_records_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  CONSTRAINT `financial_records_ibfk_3` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `financial_records_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `financial_records_ibfk_5` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `financial_records` VALUES ('1', 'income', '2500000.00', '', NULL, NULL, NULL, NULL, 'UNESCO astronomy education grant tranche 1', '2', NULL, NULL, '2026-08-01', NULL, 'approved', NULL, NULL, '2026-08-14 09:42:34');
INSERT INTO `financial_records` VALUES ('2', 'expense', '450000.00', 'equipment', NULL, NULL, NULL, NULL, 'Star party telescopes hire', '2', NULL, NULL, '2026-08-05', NULL, 'approved', NULL, NULL, '2026-08-14 09:42:34');
INSERT INTO `financial_records` VALUES ('3', 'income', '500000.00', 'membership', NULL, NULL, NULL, NULL, 'Membership fees — Q2 2026', '5', NULL, NULL, '2026-08-14', NULL, 'approved', NULL, NULL, '2026-08-14 13:18:38');
INSERT INTO `financial_records` VALUES ('4', 'income', '2000000.00', 'other', NULL, NULL, NULL, NULL, 'IAU OAD micro-grant for education programme', '5', NULL, NULL, '2026-08-14', NULL, 'approved', NULL, NULL, '2026-08-14 13:18:38');
INSERT INTO `financial_records` VALUES ('5', 'expense', '250000.00', 'equipment', NULL, NULL, NULL, NULL, 'Telescope maintenance kits', '5', NULL, NULL, '2026-08-14', NULL, 'approved', NULL, NULL, '2026-08-14 13:18:38');
INSERT INTO `financial_records` VALUES ('6', 'expense', '180000.00', 'other', NULL, NULL, NULL, NULL, 'July public night — generator fuel and permits', '5', NULL, NULL, '2026-08-14', NULL, 'approved', NULL, NULL, '2026-08-14 13:18:38');
INSERT INTO `financial_records` VALUES ('7', 'income', '320000.00', 'event', NULL, NULL, NULL, NULL, 'Public night guest entry fees — July', '5', NULL, NULL, '2026-08-14', NULL, 'approved', NULL, NULL, '2026-08-14 13:18:38');
INSERT INTO `financial_records` VALUES ('8', 'income', '50000000.00', 'grant', '1', NULL, NULL, NULL, 'Grant from National Science Foundation', '1', NULL, NULL, '2026-02-15', '2026-02-15', 'approved', NULL, 'NSF research grant for 2026 programmes', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('9', 'income', '15000000.00', 'sponsorship', '1', NULL, NULL, NULL, 'Corporate Sponsorship — MTN Uganda', '2', NULL, NULL, '2026-03-01', '2026-03-01', 'approved', NULL, 'Annual corporate sponsorship', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('10', 'income', '3200000.00', 'membership', '1', NULL, NULL, NULL, 'Member Registration Fees (Q1)', '1', NULL, NULL, '2026-03-31', '2026-03-31', 'approved', NULL, '16 new members × UGX 200,000', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('11', 'income', '2400000.00', 'event', '1', NULL, '1', NULL, 'Event Ticket Sales — Stargazing Night', '1', NULL, NULL, '2026-08-20', '2026-08-20', 'approved', NULL, '80 attendees × UGX 30,000', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('12', 'income', '1500000.00', 'training', '2', NULL, '3', NULL, 'Telescope Workshop Fees', '3', NULL, NULL, '2026-09-16', '2026-09-16', 'approved', NULL, '25 participants × UGX 60,000', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('13', 'expense', '8500000.00', 'equipment', '1', NULL, NULL, NULL, 'Equipment Purchase — Dobsonian 12\" (KIS)', '4', NULL, NULL, '2026-08-15', '2026-08-15', 'paid', NULL, 'Third school telescope installation', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('14', 'expense', '6000000.00', 'administration', '1', NULL, NULL, NULL, 'Staff Salaries (Aug 2026)', '1', NULL, NULL, '2026-08-31', '2026-08-31', 'paid', NULL, 'Monthly salaries', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('15', 'expense', '850000.00', 'other', '1', NULL, NULL, NULL, 'Internet & Software Licenses', '1', NULL, NULL, '2026-09-01', '2026-09-01', 'paid', NULL, 'Monthly recurring', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('16', 'expense', '3200000.00', 'travel', '3', NULL, NULL, NULL, 'Murchison Field Trip Transport', '4', NULL, NULL, '2026-10-20', '2026-10-20', 'approved', NULL, 'Bus hire and fuel for 25 observers', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('17', 'expense', '1200000.00', 'publication', '3', NULL, NULL, NULL, 'Printing — Star Atlases & Pamphlets', '2', NULL, NULL, '2026-11-01', '2026-11-01', 'approved', NULL, 'Educational materials for outreach', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('18', 'payable', '2000000.00', 'event', '1', NULL, NULL, NULL, 'Venue Rental — Makerere Hall', '1', NULL, NULL, '2026-11-20', '2026-11-20', 'approved', NULL, 'AGM venue booking', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('19', 'receivable', '30000000.00', 'grant', '1', NULL, NULL, NULL, 'Pending Grant from UNESCO', '1', NULL, NULL, '2026-12-31', '2026-12-31', 'pending', NULL, 'UNESCO astronomy education grant application', '2026-08-18 09:33:55');
INSERT INTO `financial_records` VALUES ('20', 'receivable', '5000000.00', 'sponsorship', '1', NULL, NULL, NULL, 'Sponsorship — UWA Events', '1', NULL, NULL, '2026-10-15', '2026-10-15', 'pending', NULL, 'Joint astronomy tourism events', '2026-08-18 09:33:55');

DROP TABLE IF EXISTS `members`;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `membership_number` varchar(50) DEFAULT NULL,
  `category` enum('regular','student','honorary','institutional') DEFAULT 'regular',
  `status` enum('active','inactive','suspended','pending','rejected') DEFAULT 'pending',
  `joined_date` date DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `profile_visible` tinyint(1) DEFAULT 0,
  `interests` text DEFAULT NULL,
  `contributions` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `membership_number` (`membership_number`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `members_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `members` VALUES ('1', '1', 'UAS-2026-0001', 'regular', 'active', '2026-08-13', NULL, NULL, '0', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `members` VALUES ('2', '2', 'UAS-2026-0003', 'regular', 'active', '2026-08-13', NULL, NULL, '0', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `members` VALUES ('3', '3', 'UAS-2026-0004', 'regular', 'active', '2026-08-13', NULL, NULL, '0', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `members` VALUES ('4', '4', 'UAS-2026-0005', 'regular', 'active', '2026-08-13', NULL, NULL, '0', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `members` VALUES ('5', '5', 'UAS-2026-0006', 'regular', 'active', '2026-08-13', NULL, NULL, '0', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `members` VALUES ('7', '7', 'UAS-2026-0007', 'student', 'active', '2026-08-13', '1', '2026-08-13 19:53:44', '1', 'observing, astrophotography', NULL, '2026-08-13 19:53:04');
INSERT INTO `members` VALUES ('8', '8', 'UAS-2026-0008', 'student', 'active', '2026-02-10', NULL, NULL, '1', 'variable stars, double stars', NULL, '2026-08-14 13:18:22');
INSERT INTO `members` VALUES ('9', '9', 'UAS-2026-0009', 'regular', 'active', '2026-03-22', NULL, NULL, '1', 'astrophotography, outreach', NULL, '2026-08-14 13:18:22');
INSERT INTO `members` VALUES ('10', '10', 'UAS-2026-0010', 'regular', 'active', '2025-11-05', NULL, NULL, '1', 'meteorology, climate, observing', NULL, '2026-08-14 13:18:22');
INSERT INTO `members` VALUES ('11', '11', 'UAS-2026-0011', 'student', 'active', '2026-08-14', NULL, NULL, '0', NULL, NULL, '2026-08-14 14:02:34');
INSERT INTO `members` VALUES ('12', '12', 'UAS-2026-0012', 'regular', 'active', '2026-08-14', NULL, NULL, '0', NULL, NULL, '2026-08-14 14:02:34');
INSERT INTO `members` VALUES ('13', '13', 'UAS-2026-0023', 'regular', 'active', '2026-08-18', NULL, NULL, '1', NULL, NULL, '2026-08-18 09:34:25');
INSERT INTO `members` VALUES ('14', '14', 'UAS-2026-0024', 'regular', 'active', '2026-08-18', NULL, NULL, '1', NULL, NULL, '2026-08-18 09:34:25');
INSERT INTO `members` VALUES ('15', '15', 'UAS-2026-0025', 'regular', 'active', '2026-08-18', NULL, NULL, '1', NULL, NULL, '2026-08-18 09:34:25');
INSERT INTO `members` VALUES ('16', '16', 'UAS-2026-0026', 'student', 'active', '2026-08-18', NULL, NULL, '1', NULL, NULL, '2026-08-18 09:34:25');

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(40) NOT NULL DEFAULT 'info',
  `title` varchar(160) NOT NULL,
  `body` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notif_user` (`user_id`,`is_read`,`created_at`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `notifications` VALUES ('1', '1', 'contact_message', 'New contact message from Visitor', 'Hello UAS team, great site!', '/admin?tab=inbox', '0', '2026-08-14 15:59:25');
INSERT INTO `notifications` VALUES ('2', '2', 'contact_message', 'New contact message from Visitor', 'Hello UAS team, great site!', '/admin?tab=inbox', '0', '2026-08-14 15:59:25');
INSERT INTO `notifications` VALUES ('3', '3', 'contact_message', 'New contact message from Visitor', 'Hello UAS team, great site!', '/admin?tab=inbox', '0', '2026-08-14 15:59:25');
INSERT INTO `notifications` VALUES ('4', '4', 'contact_message', 'New contact message from Visitor', 'Hello UAS team, great site!', '/admin?tab=inbox', '0', '2026-08-14 15:59:25');
INSERT INTO `notifications` VALUES ('5', '5', 'contact_message', 'New contact message from Visitor', 'Hello UAS team, great site!', '/admin?tab=inbox', '0', '2026-08-14 15:59:25');
INSERT INTO `notifications` VALUES ('6', '9', 'article_approved', 'Article approved: Bell test article', 'Your article has been approved and is ready to publish.', '/article/10', '1', '2026-08-14 15:59:56');
INSERT INTO `notifications` VALUES ('7', '9', 'article_published', 'Article published: Bell test article', 'Your article is now live on the site.', '/article/10', '1', '2026-08-14 15:59:56');
INSERT INTO `notifications` VALUES ('8', '4', 'event_submitted', 'Event awaiting approval: Bell Test Event', 'Submitted by Grace Achieng.', '/admin?tab=events', '0', '2026-08-14 15:59:56');
INSERT INTO `notifications` VALUES ('9', '1', 'event_submitted', 'Event awaiting approval: Bell Test Event', 'Submitted by Grace Achieng.', '/admin?tab=events', '0', '2026-08-14 15:59:56');
INSERT INTO `notifications` VALUES ('10', '2', 'event_submitted', 'Event awaiting approval: Bell Test Event', 'Submitted by Grace Achieng.', '/admin?tab=events', '0', '2026-08-14 15:59:56');
INSERT INTO `notifications` VALUES ('11', '3', 'event_submitted', 'Event awaiting approval: Bell Test Event', 'Submitted by Grace Achieng.', '/admin?tab=events', '0', '2026-08-14 15:59:56');
INSERT INTO `notifications` VALUES ('12', '5', 'event_submitted', 'Event awaiting approval: Bell Test Event', 'Submitted by Grace Achieng.', '/admin?tab=events', '0', '2026-08-14 15:59:56');
INSERT INTO `notifications` VALUES ('13', '9', 'event_published', 'Event live: Bell Test Event', 'Your event has been approved and is now open for RSVPs.', '/event/6', '1', '2026-08-14 15:59:56');
INSERT INTO `notifications` VALUES ('14', '5', 'assignment_assigned', 'New assignment: Draft observing report', 'An assignment has been given to you (due 2026-09-01).', '/dashboard', '0', '2026-08-14 16:00:09');
INSERT INTO `notifications` VALUES ('15', '7', 'assignment_assigned', 'New assignment: Draft observing report v2', 'An assignment has been given to you (due 2026-09-01).', '/dashboard', '0', '2026-08-14 16:00:23');
INSERT INTO `notifications` VALUES ('16', '9', 'waitlist_promote', 'Spot secured: Astronomy Education Workshop: Teachers Bootcamp', 'A spot opened up and you have been auto-promoted from the waitlist to registered.', '/event/3', '0', '2026-08-14 16:00:45');

DROP TABLE IF EXISTS `partners`;
CREATE TABLE `partners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `logo_url` varchar(500) DEFAULT NULL,
  `website` varchar(500) DEFAULT NULL,
  `relationship_type` enum('partner','affiliate','sponsor','institutional') DEFAULT 'partner',
  `status` enum('active','inactive') DEFAULT 'active',
  `associated_programmes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`associated_programmes`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `partners` VALUES ('1', 'Ministry of Science, Technology and Innovation', 'Government ministry overseeing science and technology policy in Uganda', NULL, NULL, 'institutional', 'active', NULL, '2026-08-13 19:18:17');
INSERT INTO `partners` VALUES ('2', 'UNESCO', NULL, NULL, 'https://unesco.org', 'institutional', 'inactive', NULL, '2026-08-14 09:57:06');
INSERT INTO `partners` VALUES ('3', 'UNESCO', 'Education, science and culture agency ù supports astronomy education programmes', NULL, 'https://unesco.org', 'institutional', 'active', NULL, '2026-08-14 09:57:14');
INSERT INTO `partners` VALUES ('4', 'International Astronomical Union (OAD)', 'Global astronomy advocacy and development network', NULL, 'https://astro4dev.org', 'sponsor', 'active', NULL, '2026-08-14 13:18:51');
INSERT INTO `partners` VALUES ('5', 'Makerere University Physics Department', 'Academic partner for outreach and training', NULL, 'https://cns.mak.ac.ug', 'partner', 'active', NULL, '2026-08-14 13:18:51');
INSERT INTO `partners` VALUES ('6', 'Galileo Telescopes Ltd', 'Equipment supplier for school telescope rollout', NULL, NULL, 'partner', 'active', NULL, '2026-08-14 13:18:51');

DROP TABLE IF EXISTS `programmes`;
CREATE TABLE `programmes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `status` enum('draft','active','paused','completed','archived') DEFAULT 'draft',
  `budget` decimal(15,2) DEFAULT 0.00,
  `spent` decimal(15,2) DEFAULT 0.00,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `objectives` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `programmes_ibfk_1` FOREIGN KEY (`lead_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `programmes_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `programmes` VALUES ('1', 'Astronomy Education Programme', 'UAS flagship programme for astronomy education across Ugandan schools and universities', '4', 'active', '0.00', '0.00', NULL, NULL, 'Increase astronomy literacy and inspire the next generation of Ugandan astronomers', '1', '2026-08-13 19:18:17', '2026-08-14 10:22:54');
INSERT INTO `programmes` VALUES ('2', 'Research & Citizen Science', 'Supporting variable star observing, meteor counting, and collaboration with regional observatories.', '2', 'active', '0.00', '0.00', NULL, NULL, 'Coordinate citizen science campaigns\nPublish observing reports\nLink with regional astronomy research', '1', '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `programmes` VALUES ('3', 'Women in Astronomy Initiative', 'Mentorship, scholarships, and visibility for women pursuing physics and astronomy in Uganda.', '5', 'active', '0.00', '0.00', NULL, NULL, 'Annual mentorship cohort\nScholarship support for STEM students\nPublic role-model profiles', '1', '2026-08-14 13:18:22', '2026-08-14 13:18:22');

DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `programme_id` int(11) DEFAULT NULL,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `status` enum('draft','active','on_hold','completed','archived') DEFAULT 'draft',
  `objectives` text DEFAULT NULL,
  `milestones` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`milestones`)),
  `deadline` date DEFAULT NULL,
  `budget` decimal(15,2) DEFAULT 0.00,
  `spent` decimal(15,2) DEFAULT 0.00,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `programme_id` (`programme_id`),
  KEY `lead_id` (`lead_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`programme_id`) REFERENCES `programmes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `projects_ibfk_2` FOREIGN KEY (`lead_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `projects_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `projects` VALUES ('1', NULL, 'Campus Planetarium Initiative', 'Portable planetarium tours to schools', NULL, 'draft', '10 schools in year one', NULL, '2027-03-01', '0.00', '0.00', '4', '2026-08-14 09:45:21', '2026-08-14 09:45:21');
INSERT INTO `projects` VALUES ('2', '1', 'School Telescope Programme', 'Distribute and train teachers on donated telescopes in 10 schools across Uganda', '4', 'active', 'Equip 10 schools with telescopes and train 20 teachers', NULL, '2026-12-15', '5000000.00', '0.00', NULL, '2026-08-14 10:22:54', '2026-08-14 10:22:54');
INSERT INTO `projects` VALUES ('3', '1', 'Astronomy Club Network', 'Establish and support astronomy clubs at universities and secondary schools', '4', 'active', 'Support 15 astronomy clubs with activity kits and mentoring', NULL, '2027-03-30', '3000000.00', '0.00', NULL, '2026-08-14 10:22:54', '2026-08-14 10:22:54');
INSERT INTO `projects` VALUES ('4', '2', 'Variable Star Campaign', 'Monthly photometry runs on bright southern variables, reporting to AAVSO', '2', 'active', '200 reported observations in 2026', NULL, '2026-12-31', '1200000.00', '0.00', '1', '2026-08-14 13:18:22', '2026-08-14 13:18:22');
INSERT INTO `projects` VALUES ('5', '3', 'Women in STEM Scholarship Fund', 'Raise and disburse scholarships for female physics students', '5', 'active', '5 scholarships awarded by 2027', NULL, '2027-06-30', '15000000.00', '0.00', '1', '2026-08-14 13:18:22', '2026-08-14 13:18:22');

DROP TABLE IF EXISTS `rate_limits`;
CREATE TABLE `rate_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rl_key` varchar(190) NOT NULL,
  `rl_type` varchar(40) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 1,
  `window_start` datetime NOT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rl_key` (`rl_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `rate_limits` VALUES ('1', 'login-ip:::1', 'login', '1', '2026-08-18 09:57:43', '2026-08-18 10:57:43');
INSERT INTO `rate_limits` VALUES ('2', 'login:admin@astronomy.ug', 'login', '1', '2026-08-18 09:57:43', '2026-08-18 10:57:43');

DROP TABLE IF EXISTS `resolution_changes`;
CREATE TABLE `resolution_changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resolution_id` int(11) NOT NULL,
  `change_type` enum('role_create','role_modify','role_delete','cap_assign','cap_revoke','appoint','remove','policy_adopt','policy_amend','committee_create','committee_dissolve','programme_create','programme_close','budget_approve','financial_auth') NOT NULL,
  `target_type` varchar(100) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`payload`)),
  `applied` tinyint(1) DEFAULT 0,
  `applied_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `resolution_id` (`resolution_id`),
  CONSTRAINT `resolution_changes_ibfk_1` FOREIGN KEY (`resolution_id`) REFERENCES `resolutions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `resolution_changes` VALUES ('5', '3', 'role_create', NULL, NULL, '{\"title\":\"Head of Science\",\"description\":\"Leads UAS scientific output review\",\"capability_ids\":[4,5]}', '1', '2026-08-13 19:49:54', '2026-08-13 19:48:02');
INSERT INTO `resolution_changes` VALUES ('6', '4', 'appoint', NULL, NULL, '{\"role_id\":5,\"user_id\":4}', '1', '2026-08-13 19:50:19', '2026-08-13 19:50:19');
INSERT INTO `resolution_changes` VALUES ('7', '5', 'role_create', NULL, NULL, '{\"title\":\"Outreach Coordinator\",\"description\":\"Coordinates public outreach events\",\"capability_ids\":[\"events.approve\",\"events.publish\",\"articles.approve\"]}', '1', '2026-08-13 19:57:04', '2026-08-13 19:57:04');
INSERT INTO `resolution_changes` VALUES ('10', '7', 'role_create', NULL, NULL, '{\"title\":\"Outreach Coordinator\",\"description\":\"Coordinates public outreach and school visits\",\"capabilities\":[\"events.create\",\"events.rsvp\",\"articles.submit\"]}', '1', '2026-08-14 13:21:05', '2026-08-14 13:21:05');
INSERT INTO `resolution_changes` VALUES ('11', '7', 'appoint', 'role', NULL, '{\"user_id\":8,\"role_title\":\"Outreach Coordinator\"}', '1', '2026-08-14 13:21:05', '2026-08-14 13:21:05');
INSERT INTO `resolution_changes` VALUES ('14', '9', 'role_create', NULL, NULL, '{\"title\":\"Communications Officer\",\"description\":\"Manages public communications, social media and newsletters\",\"capabilities\":[\"articles.submit\",\"articles.review\",\"events.create\",\"events.rsvp\"]}', '1', '2026-08-14 13:22:22', '2026-08-14 13:22:22');
INSERT INTO `resolution_changes` VALUES ('15', '9', 'appoint', 'role', NULL, '{\"user_id\":9,\"role_title\":\"Communications Officer\"}', '1', '2026-08-14 13:22:22', '2026-08-14 13:22:22');

DROP TABLE IF EXISTS `resolution_comments`;
CREATE TABLE `resolution_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resolution_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `parent_id` (`parent_id`),
  KEY `idx_rc_resolution` (`resolution_id`),
  CONSTRAINT `resolution_comments_ibfk_1` FOREIGN KEY (`resolution_id`) REFERENCES `resolutions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `resolution_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `resolution_comments_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `resolution_comments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `resolution_comments` VALUES ('1', '9', '1', NULL, 'Support this resolution.', '2026-08-18 09:35:07', '2026-08-18 09:35:07');

DROP TABLE IF EXISTS `resolutions`;
CREATE TABLE `resolutions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('role_create','role_modify','role_delete','capability_assign','capability_revoke','appointment','removal','policy_adopt','policy_amend','committee_create','committee_dissolve','programme_create','programme_close','budget_approve','financial_authorization','general_poll','constitutional_amendment') NOT NULL,
  `status` enum('draft','submitted','voting','passed','failed','applied','rejected') DEFAULT 'draft',
  `proposed_by` int(11) NOT NULL,
  `body_id` int(11) DEFAULT NULL,
  `quorum` int(11) DEFAULT 0,
  `majority` varchar(20) DEFAULT 'simple',
  `voting_deadline` timestamp NULL DEFAULT NULL,
  `votes_for` int(11) DEFAULT 0,
  `votes_against` int(11) DEFAULT 0,
  `votes_abstain` int(11) DEFAULT 0,
  `passed_at` timestamp NULL DEFAULT NULL,
  `applied_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `proposed_by` (`proposed_by`),
  CONSTRAINT `resolutions_ibfk_1` FOREIGN KEY (`proposed_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `resolutions` VALUES ('3', 'UAS-BRD-2026-001', 'Establish the Head of Science portfolio', 'Create the Head of Science role with authority to review and approve scientific articles.', 'role_create', 'applied', '1', NULL, '3', 'two_thirds', '2026-08-20 23:59:59', '3', '0', '0', '2026-08-13 19:49:54', '2026-08-13 19:49:54', '2026-08-13 19:48:02', '2026-08-13 19:49:54');
INSERT INTO `resolutions` VALUES ('4', 'UAS-BRD-2026-002', 'Appoint Dr. John Mukasa as Head of Science', 'Appoint Dr. John Mukasa to the Head of Science portfolio established by UAS-BRD-2026-003.', '', 'applied', '1', NULL, '3', 'two_thirds', NULL, '3', '0', '0', '2026-08-13 19:50:19', '2026-08-13 19:50:19', '2026-08-13 19:50:19', '2026-08-13 19:50:19');
INSERT INTO `resolutions` VALUES ('5', 'UAS-BRD-2026-003', 'Create Outreach Coordinator role', 'Establish outreach portfolio with events + article approval powers (slug-based caps).', 'role_create', 'applied', '1', NULL, '3', 'two_thirds', NULL, '3', '0', '0', '2026-08-13 19:57:04', '2026-08-13 19:57:04', '2026-08-13 19:57:04', '2026-08-13 19:57:04');
INSERT INTO `resolutions` VALUES ('7', 'UAS-BRD-2026-004', 'Create Outreach Coordinator role and appoint Peter Okello', 'Formalizes the outreach function and appoints Peter Okello to lead it.', 'role_create', 'applied', '2', NULL, '3', 'simple', '2026-08-28 12:21:05', '3', '0', '0', '2026-08-14 13:21:05', '2026-08-14 13:21:05', '2026-08-14 13:21:05', '2026-08-14 13:21:05');
INSERT INTO `resolutions` VALUES ('9', 'UAS-BRD-2026-005', 'Create Communications Officer role and appoint Grace Achieng', 'Creates the Communications Officer portfolio and appoints Grace Achieng to manage public communications.', 'role_create', 'applied', '2', NULL, '3', 'simple', '2026-08-28 12:22:22', '3', '0', '0', '2026-08-14 13:22:22', '2026-08-14 13:22:22', '2026-08-14 13:22:22', '2026-08-14 13:22:22');

DROP TABLE IF EXISTS `role_assignments`;
CREATE TABLE `role_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `resolution_id` int(11) DEFAULT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `status` enum('active','inactive','revoked') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_user_active` (`role_id`,`user_id`,`status`),
  KEY `user_id` (`user_id`),
  KEY `assigned_by` (`assigned_by`),
  CONSTRAINT `role_assignments_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_assignments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_assignments_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `role_assignments` VALUES ('1', '1', '2', '1', NULL, '2026-08-13', NULL, 'active', '2026-08-13 19:18:17');
INSERT INTO `role_assignments` VALUES ('2', '1', '3', '1', NULL, '2026-08-13', NULL, 'active', '2026-08-13 19:18:17');
INSERT INTO `role_assignments` VALUES ('3', '1', '4', '1', NULL, '2026-08-13', NULL, 'active', '2026-08-13 19:18:17');
INSERT INTO `role_assignments` VALUES ('4', '1', '5', '1', NULL, '2026-08-13', NULL, 'active', '2026-08-13 19:18:17');
INSERT INTO `role_assignments` VALUES ('5', '1', '1', '1', NULL, '2026-08-13', NULL, 'active', '2026-08-13 19:18:35');
INSERT INTO `role_assignments` VALUES ('6', '5', '4', '1', '4', '2026-08-13', NULL, 'active', '2026-08-13 19:50:19');
INSERT INTO `role_assignments` VALUES ('7', '6', '7', '1', NULL, '2026-08-13', NULL, 'active', '2026-08-13 19:53:44');
INSERT INTO `role_assignments` VALUES ('8', '4', '4', '1', NULL, '2026-08-14', NULL, 'active', '2026-08-14 09:45:21');
INSERT INTO `role_assignments` VALUES ('9', '6', '8', '1', NULL, '2026-08-14', NULL, 'active', '2026-08-14 13:18:22');
INSERT INTO `role_assignments` VALUES ('10', '6', '9', '1', NULL, '2026-08-14', NULL, 'active', '2026-08-14 13:18:22');
INSERT INTO `role_assignments` VALUES ('11', '6', '10', '1', NULL, '2026-08-14', NULL, 'active', '2026-08-14 13:18:22');
INSERT INTO `role_assignments` VALUES ('12', '10', '9', '2', '9', '2026-08-14', NULL, 'active', '2026-08-14 13:22:22');
INSERT INTO `role_assignments` VALUES ('13', '6', '11', '1', NULL, '2026-08-14', NULL, 'active', '2026-08-14 14:02:34');
INSERT INTO `role_assignments` VALUES ('14', '6', '12', '1', NULL, '2026-08-14', NULL, 'active', '2026-08-14 14:02:34');
INSERT INTO `role_assignments` VALUES ('15', '4', '13', '1', NULL, '2026-08-18', NULL, 'active', '2026-08-18 09:34:25');
INSERT INTO `role_assignments` VALUES ('16', '6', '13', '1', NULL, '2026-08-18', NULL, 'active', '2026-08-18 09:34:25');
INSERT INTO `role_assignments` VALUES ('17', '10', '14', '1', NULL, '2026-08-18', NULL, 'active', '2026-08-18 09:34:25');
INSERT INTO `role_assignments` VALUES ('18', '6', '14', '1', NULL, '2026-08-18', NULL, 'active', '2026-08-18 09:34:25');
INSERT INTO `role_assignments` VALUES ('19', '3', '15', '1', NULL, '2026-08-18', NULL, 'active', '2026-08-18 09:34:25');
INSERT INTO `role_assignments` VALUES ('20', '6', '15', '1', NULL, '2026-08-18', NULL, 'active', '2026-08-18 09:34:25');
INSERT INTO `role_assignments` VALUES ('21', '6', '16', '1', NULL, '2026-08-18', NULL, 'active', '2026-08-18 09:34:25');

DROP TABLE IF EXISTS `role_capabilities`;
CREATE TABLE `role_capabilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `capability_id` int(11) NOT NULL,
  `granted_by` int(11) DEFAULT NULL,
  `scope_type` varchar(50) DEFAULT NULL,
  `scope_id` int(11) DEFAULT NULL,
  `granted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_cap_scope` (`role_id`,`capability_id`,`scope_type`,`scope_id`),
  KEY `capability_id` (`capability_id`),
  KEY `granted_by` (`granted_by`),
  CONSTRAINT `role_capabilities_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_capabilities_ibfk_2` FOREIGN KEY (`capability_id`) REFERENCES `capabilities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_capabilities_ibfk_3` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `role_capabilities` VALUES ('1', '2', '3', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('2', '2', '4', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('3', '2', '5', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('4', '2', '10', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('5', '2', '11', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('6', '3', '4', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('7', '3', '10', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('8', '3', '14', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('9', '3', '34', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('10', '4', '14', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('11', '4', '18', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('12', '4', '10', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('13', '4', '34', '1', NULL, NULL, '2026-08-13 19:18:17');
INSERT INTO `role_capabilities` VALUES ('14', '1', '23', NULL, NULL, NULL, '2026-08-13 19:18:35');
INSERT INTO `role_capabilities` VALUES ('15', '1', '25', NULL, NULL, NULL, '2026-08-13 19:18:35');
INSERT INTO `role_capabilities` VALUES ('16', '1', '24', NULL, NULL, NULL, '2026-08-13 19:18:35');
INSERT INTO `role_capabilities` VALUES ('17', '5', '4', '1', NULL, NULL, '2026-08-13 19:49:54');
INSERT INTO `role_capabilities` VALUES ('18', '5', '5', '1', NULL, NULL, '2026-08-13 19:49:54');
INSERT INTO `role_capabilities` VALUES ('19', '1', '39', NULL, NULL, NULL, '2026-08-13 19:53:39');
INSERT INTO `role_capabilities` VALUES ('20', '1', '31', NULL, NULL, NULL, '2026-08-13 19:53:39');
INSERT INTO `role_capabilities` VALUES ('21', '1', '21', NULL, NULL, NULL, '2026-08-13 19:53:39');
INSERT INTO `role_capabilities` VALUES ('22', '1', '22', NULL, NULL, NULL, '2026-08-13 19:53:39');
INSERT INTO `role_capabilities` VALUES ('23', '1', '20', NULL, NULL, NULL, '2026-08-13 19:53:39');
INSERT INTO `role_capabilities` VALUES ('24', '1', '36', NULL, NULL, NULL, '2026-08-13 19:53:39');
INSERT INTO `role_capabilities` VALUES ('25', '1', '35', NULL, NULL, NULL, '2026-08-13 19:53:39');
INSERT INTO `role_capabilities` VALUES ('26', '1', '37', NULL, NULL, NULL, '2026-08-13 19:53:39');
INSERT INTO `role_capabilities` VALUES ('27', '1', '38', NULL, NULL, NULL, '2026-08-13 19:53:39');
INSERT INTO `role_capabilities` VALUES ('34', '6', '1', '1', NULL, NULL, '2026-08-13 19:53:44');
INSERT INTO `role_capabilities` VALUES ('35', '6', '7', '1', NULL, NULL, '2026-08-13 19:53:44');
INSERT INTO `role_capabilities` VALUES ('36', '6', '27', '1', NULL, NULL, '2026-08-13 19:53:44');
INSERT INTO `role_capabilities` VALUES ('37', '6', '34', '1', NULL, NULL, '2026-08-13 19:53:44');
INSERT INTO `role_capabilities` VALUES ('38', '5', '3', NULL, NULL, NULL, '2026-08-13 19:54:43');
INSERT INTO `role_capabilities` VALUES ('39', '5', '9', NULL, NULL, NULL, '2026-08-13 19:54:43');
INSERT INTO `role_capabilities` VALUES ('41', '1', '29', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('42', '1', '30', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('43', '1', '28', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('44', '1', '10', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('45', '1', '12', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('46', '1', '11', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('47', '1', '33', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('48', '1', '32', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('49', '1', '15', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('50', '1', '18', NULL, NULL, NULL, '2026-08-13 19:55:40');
INSERT INTO `role_capabilities` VALUES ('56', '7', '10', '1', NULL, NULL, '2026-08-13 19:57:04');
INSERT INTO `role_capabilities` VALUES ('57', '7', '11', '1', NULL, NULL, '2026-08-13 19:57:04');
INSERT INTO `role_capabilities` VALUES ('58', '7', '4', '1', NULL, NULL, '2026-08-13 19:57:04');
INSERT INTO `role_capabilities` VALUES ('59', '4', '16', NULL, NULL, NULL, '2026-08-14 09:43:16');
INSERT INTO `role_capabilities` VALUES ('60', '4', '17', NULL, NULL, NULL, '2026-08-14 09:43:16');
INSERT INTO `role_capabilities` VALUES ('62', '3', '13', NULL, NULL, NULL, '2026-08-14 09:45:05');
INSERT INTO `role_capabilities` VALUES ('63', '4', '13', NULL, NULL, NULL, '2026-08-14 09:45:05');
INSERT INTO `role_capabilities` VALUES ('65', '1', '40', NULL, NULL, NULL, '2026-08-14 09:51:21');
INSERT INTO `role_capabilities` VALUES ('66', '2', '40', NULL, NULL, NULL, '2026-08-14 09:51:21');
INSERT INTO `role_capabilities` VALUES ('67', '3', '40', NULL, NULL, NULL, '2026-08-14 09:51:21');
INSERT INTO `role_capabilities` VALUES ('68', '4', '40', NULL, NULL, NULL, '2026-08-14 09:51:21');
INSERT INTO `role_capabilities` VALUES ('69', '5', '40', NULL, NULL, NULL, '2026-08-14 09:51:21');
INSERT INTO `role_capabilities` VALUES ('70', '6', '40', NULL, NULL, NULL, '2026-08-14 09:51:21');
INSERT INTO `role_capabilities` VALUES ('72', '1', '41', NULL, NULL, NULL, '2026-08-14 09:52:59');
INSERT INTO `role_capabilities` VALUES ('73', '4', '41', NULL, NULL, NULL, '2026-08-14 09:52:59');
INSERT INTO `role_capabilities` VALUES ('75', '1', '43', NULL, NULL, NULL, '2026-08-14 09:56:45');
INSERT INTO `role_capabilities` VALUES ('76', '1', '42', NULL, NULL, NULL, '2026-08-14 09:56:45');
INSERT INTO `role_capabilities` VALUES ('78', '1', '44', NULL, NULL, NULL, '2026-08-14 11:30:35');
INSERT INTO `role_capabilities` VALUES ('79', '4', '44', NULL, NULL, NULL, '2026-08-14 11:30:35');
INSERT INTO `role_capabilities` VALUES ('81', '10', '1', '2', NULL, NULL, '2026-08-14 13:22:22');
INSERT INTO `role_capabilities` VALUES ('82', '10', '3', '2', NULL, NULL, '2026-08-14 13:22:22');
INSERT INTO `role_capabilities` VALUES ('83', '10', '7', '2', NULL, NULL, '2026-08-14 13:22:22');
INSERT INTO `role_capabilities` VALUES ('84', '10', '40', '2', NULL, NULL, '2026-08-14 13:22:22');
INSERT INTO `role_capabilities` VALUES ('85', '1', '4', NULL, NULL, NULL, '2026-08-14 13:23:30');
INSERT INTO `role_capabilities` VALUES ('86', '1', '2', NULL, NULL, NULL, '2026-08-14 13:23:30');
INSERT INTO `role_capabilities` VALUES ('87', '1', '5', NULL, NULL, NULL, '2026-08-14 13:23:30');
INSERT INTO `role_capabilities` VALUES ('88', '1', '3', NULL, NULL, NULL, '2026-08-14 13:23:30');
INSERT INTO `role_capabilities` VALUES ('89', '1', '1', NULL, NULL, NULL, '2026-08-14 13:23:30');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `scope` varchar(100) DEFAULT NULL,
  `term_start` date DEFAULT NULL,
  `term_end` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `resolution_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `roles` VALUES ('1', 'Board Director', 'Member of the UAS Board of Directors', 'active', NULL, NULL, NULL, '1', NULL, '2026-08-13 19:18:17', '2026-08-13 19:18:17');
INSERT INTO `roles` VALUES ('2', 'PR Director', 'Manages public relations and communications', 'active', NULL, NULL, NULL, '1', NULL, '2026-08-13 19:18:17', '2026-08-13 19:18:17');
INSERT INTO `roles` VALUES ('3', 'Education WG Lead', 'Leads the Education Working Group', 'active', NULL, NULL, NULL, '1', NULL, '2026-08-13 19:18:17', '2026-08-13 19:18:17');
INSERT INTO `roles` VALUES ('4', 'Programme Lead', 'Oversees programme execution', 'active', NULL, NULL, NULL, '1', NULL, '2026-08-13 19:18:17', '2026-08-13 19:18:17');
INSERT INTO `roles` VALUES ('5', 'Head of Science', 'Leads UAS scientific output review', 'active', NULL, NULL, NULL, '1', '3', '2026-08-13 19:49:54', '2026-08-13 19:49:54');
INSERT INTO `roles` VALUES ('6', 'Member', 'Baseline membership role', 'active', NULL, NULL, NULL, '1', NULL, '2026-08-13 19:53:44', '2026-08-13 19:53:44');
INSERT INTO `roles` VALUES ('7', 'Outreach Coordinator', 'Coordinates public outreach events', 'active', NULL, NULL, NULL, '1', '5', '2026-08-13 19:57:04', '2026-08-13 19:57:04');
INSERT INTO `roles` VALUES ('10', 'Communications Officer', 'Manages public communications, social media and newsletters', 'active', NULL, NULL, NULL, '2', '9', '2026-08-14 13:22:22', '2026-08-14 13:22:22');

DROP TABLE IF EXISTS `useful_links`;
CREATE TABLE `useful_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `url` varchar(1000) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `external_organization` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `useful_links` VALUES ('1', 'IAU', NULL, 'https://iau.org', 'Organizations', NULL, 'inactive', '2026-08-14 09:57:06');
INSERT INTO `useful_links` VALUES ('2', 'International Astronomical Union', 'The global astronomy body', 'https://www.iau.org', 'Organizations', NULL, 'active', '2026-08-14 13:18:51');
INSERT INTO `useful_links` VALUES ('3', 'American Association of Variable Star Observers', 'Citizen science variable star reporting', 'https://www.aavso.org', 'Research', NULL, 'active', '2026-08-14 13:18:51');
INSERT INTO `useful_links` VALUES ('4', 'Clear Sky Chart', 'Weather forecasting for astronomers', 'https://www.cleardarksky.com', 'Tools', NULL, 'active', '2026-08-14 13:18:51');
INSERT INTO `useful_links` VALUES ('5', 'Stellarium', 'Free planetarium software', 'https://stellarium.org', 'Tools', NULL, 'active', '2026-08-14 13:18:51');
INSERT INTO `useful_links` VALUES ('6', 'NASA Image of the Day', 'Astronomy picture of the day', 'https://apod.nasa.gov', 'Education', NULL, 'active', '2026-08-14 13:18:51');
INSERT INTO `useful_links` VALUES ('7', 'African Astronomical Society', 'Continental astronomy community', 'https://www.africanastronomicalsociety.org', 'Organizations', NULL, 'active', '2026-08-14 13:18:51');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `avatar_url` varchar(500) DEFAULT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` enum('active','suspended','pending','rejected') DEFAULT 'pending',
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` VALUES ('1', 'System Admin', 'admin@astronomy.ug', '$2y$10$HHpb9YoTnqnUeDXNAd4c3.9Q1BZ1a6lyWeDfsJCR.eA3SScG6bJoO', NULL, NULL, NULL, NULL, NULL, 'active', '2026-08-18 10:57:43', '2026-08-13 19:18:17', '2026-08-18 10:57:43');
INSERT INTO `users` VALUES ('2', 'Cosmus Ngabirano', 'cosmus@astronomy.ug', '$2y$10$qxOVB8aQCbWeHaEce/rQ.eNSHPiZ3HpfYzaHW4Y3ucJn8i/6Kctha', NULL, NULL, NULL, NULL, NULL, 'active', '2026-08-14 09:52:38', '2026-08-13 19:18:17', '2026-08-14 09:52:38');
INSERT INTO `users` VALUES ('3', 'Malcom Kintu', 'malcom@astronomy.ug', '$2y$10$JcpCtR1FAfHd4NYfotWkJe.mSOJvt/1DFpZe4NXOmLcFluex0wT96', NULL, NULL, NULL, NULL, NULL, 'active', '2026-08-14 13:58:03', '2026-08-13 19:18:17', '2026-08-14 13:58:03');
INSERT INTO `users` VALUES ('4', 'John Mukasa', 'john@astronomy.ug', '$2y$10$y8iGHa3h.8r4or97bGvJsOH.z4Pux.b0DNplA1nJ.JJg9.LWZkGY2', NULL, NULL, NULL, NULL, NULL, 'active', '2026-08-14 15:36:39', '2026-08-13 19:18:17', '2026-08-14 15:36:39');
INSERT INTO `users` VALUES ('5', 'Sarah Namukasa', 'sarah@astronomy.ug', '$2y$10$xlNyd2sdKc8ELgnueHRIp.icxUCfvgubd66L8oh/GmdQgazg3Xn5S', NULL, NULL, NULL, NULL, NULL, 'active', '2026-08-14 15:36:50', '2026-08-13 19:18:17', '2026-08-14 15:36:50');
INSERT INTO `users` VALUES ('7', 'Alice Aine', 'alice@astronomy.ug', '$2y$10$s0zERATOTqy8Wn6nc.N2iOUEd5E0/d50v0ddzRjaN0QNFqH6H2dAy', '+256700112233', NULL, NULL, 'Makerere University', 'Kampala', 'active', '2026-08-18 10:54:58', '2026-08-13 19:53:04', '2026-08-18 10:54:58');
INSERT INTO `users` VALUES ('8', 'Peter Okello', 'peter@astronomy.ug', '$2y$10$hBGZcfj8QIEfQpXBONBWwOdDKMhdYd7vkmIA2SiItanj4Y8MNhvfm', NULL, 'variable stars, double stars — passionate about variable stars, double stars', NULL, 'Gulu University', 'Gulu', 'active', '2026-08-14 16:00:31', '2026-08-14 13:18:22', '2026-08-14 16:00:31');
INSERT INTO `users` VALUES ('9', 'Grace Achieng', 'grace@astronomy.ug', '$2y$10$bCqLrSwyQChODGTliI6u7.fyip8Lwk9nZTec0MegQy2UgzEJuN0pi', NULL, 'astrophotography, outreach — passionate about astrophotography, outreach', NULL, 'Makerere University', 'Kampala', 'active', '2026-08-14 16:00:45', '2026-08-14 13:18:22', '2026-08-14 16:00:45');
INSERT INTO `users` VALUES ('10', 'Dr. Ronald Kiiza', 'ronald@astronomy.ug', '$2y$10$ZoX/9B5KNl1Cucz8GX3neuyrO7l.UAPhJ2honDVfYcDewEx2/7NQS', NULL, 'meteorology, climate, observing — passionate about meteorology, climate, observing', NULL, 'Uganda National Meteorological Authority', 'Entebbe', 'active', '2026-08-14 16:00:44', '2026-08-14 13:18:22', '2026-08-14 16:00:44');
INSERT INTO `users` VALUES ('11', 'Kato Sarah', 'sarah.kato@gmail.com', '$2y$10$31s49mmrd8cVxrk0BioEge4gPCqso0mBKB0EK8b6HAu1TfekNI/76', NULL, NULL, NULL, 'Makerere University', NULL, 'active', '2026-08-14 14:02:35', '2026-08-14 14:02:34', '2026-08-14 14:02:35');
INSERT INTO `users` VALUES ('12', 'David Ocen', 'david.ocen@yahoo.com', '$2y$10$I.3yw2H886cyI9K44aTsgeHfGGt96VsXHXS7YSHpufA.P8ChzONrO', NULL, NULL, NULL, 'Gulu University', NULL, 'active', NULL, '2026-08-14 14:02:34', '2026-08-14 14:02:34');
INSERT INTO `users` VALUES ('13', 'Dr. Patricia Owino', 'patricia@astronomy.ug', '$2y$10$KqYHgvOl.4aKzeixsSwfkOS3MXFD7mrQo.1aKNUyCgV62wHByXJ.W', NULL, NULL, NULL, 'Makerere University', 'Kampala', 'active', '2026-08-18 09:38:07', '2026-08-18 09:34:25', '2026-08-18 09:38:07');
INSERT INTO `users` VALUES ('14', 'James Okello', 'james@astronomy.ug', '$2y$10$DJbUjBtYpXtPa87cpA3D8OL3y7SVam.YxH.F5pcua.ZPFkJdE.CQW', NULL, NULL, NULL, 'Uganda National Meteorological Authority', 'Entebbe', 'active', NULL, '2026-08-18 09:34:25', '2026-08-18 09:34:25');
INSERT INTO `users` VALUES ('15', 'Nansubuga Florence', 'florence@astronomy.ug', '$2y$10$OI8934/d9wLPSFvhFbHZXuLU6F9nRiqMWnjjQlCmRpwelzbz5f55m', NULL, NULL, NULL, 'Makerere University', 'Kampala', 'active', NULL, '2026-08-18 09:34:25', '2026-08-18 09:34:25');
INSERT INTO `users` VALUES ('16', 'Brian Mugisha', 'brian@astronomy.ug', '$2y$10$blmJV3S4IoaKIGqnsSSTW.M2iEPn6PLqYkMkf3ke8Eni6Z2dGZolS', NULL, NULL, NULL, 'Kyambogo University', 'Kampala', 'active', NULL, '2026-08-18 09:34:25', '2026-08-18 09:34:25');

DROP TABLE IF EXISTS `votes`;
CREATE TABLE `votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resolution_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `value` enum('for','against','abstain') NOT NULL,
  `rationale` text DEFAULT NULL,
  `cast_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vote_once` (`resolution_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`resolution_id`) REFERENCES `resolutions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `votes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `votes` VALUES ('4', '3', '1', 'for', NULL, '2026-08-13 19:49:54');
INSERT INTO `votes` VALUES ('5', '3', '2', 'for', NULL, '2026-08-13 19:49:54');
INSERT INTO `votes` VALUES ('6', '3', '3', 'for', NULL, '2026-08-13 19:49:54');
INSERT INTO `votes` VALUES ('7', '4', '1', 'for', NULL, '2026-08-13 19:50:19');
INSERT INTO `votes` VALUES ('8', '4', '2', 'for', NULL, '2026-08-13 19:50:19');
INSERT INTO `votes` VALUES ('9', '4', '3', 'for', NULL, '2026-08-13 19:50:19');
INSERT INTO `votes` VALUES ('10', '5', '1', 'for', NULL, '2026-08-13 19:57:04');
INSERT INTO `votes` VALUES ('11', '5', '2', 'for', NULL, '2026-08-13 19:57:04');
INSERT INTO `votes` VALUES ('12', '5', '3', 'for', NULL, '2026-08-13 19:57:04');
INSERT INTO `votes` VALUES ('14', '7', '2', 'for', 'Board decision', '2026-08-14 13:21:05');
INSERT INTO `votes` VALUES ('15', '7', '3', 'for', 'Board decision', '2026-08-14 13:21:05');
INSERT INTO `votes` VALUES ('16', '7', '4', 'for', 'Board decision', '2026-08-14 13:21:05');
INSERT INTO `votes` VALUES ('20', '9', '2', 'for', 'Board decision', '2026-08-14 13:22:22');
INSERT INTO `votes` VALUES ('21', '9', '3', 'for', 'Board decision', '2026-08-14 13:22:22');
INSERT INTO `votes` VALUES ('22', '9', '4', 'for', 'Board decision', '2026-08-14 13:22:22');

DROP TABLE IF EXISTS `workflow_states`;
CREATE TABLE `workflow_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_type` varchar(100) NOT NULL,
  `object_id` int(11) NOT NULL,
  `state` varchar(50) NOT NULL,
  `assignee_role_id` int(11) DEFAULT NULL,
  `assignee_id` int(11) DEFAULT NULL,
  `entered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `due_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ws_object` (`object_type`,`object_id`),
  KEY `idx_ws_state` (`state`),
  KEY `idx_ws_assignee` (`assignee_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `workflow_states` VALUES ('1', 'resolution', '3', 'submitted', NULL, NULL, '2026-08-13 19:48:02', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('2', 'resolution', '3', 'voting', NULL, NULL, '2026-08-13 19:48:10', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('3', 'resolution', '3', 'passed', NULL, NULL, '2026-08-13 19:49:54', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('4', 'resolution', '3', 'applied', NULL, NULL, '2026-08-13 19:49:54', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('5', 'resolution', '4', 'submitted', NULL, NULL, '2026-08-13 19:50:19', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('6', 'resolution', '4', 'voting', NULL, NULL, '2026-08-13 19:50:19', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('7', 'resolution', '4', 'passed', NULL, NULL, '2026-08-13 19:50:19', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('8', 'resolution', '4', 'applied', NULL, NULL, '2026-08-13 19:50:19', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('9', 'article', '2', 'submitted', NULL, '7', '2026-08-13 19:54:11', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('10', 'article', '2', 'under_review', NULL, '4', '2026-08-13 19:54:43', NULL, 'auto-staged by approver');
INSERT INTO `workflow_states` VALUES ('11', 'article', '2', 'approved', NULL, '4', '2026-08-13 19:54:43', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('12', 'article', '2', 'published', NULL, '4', '2026-08-13 19:54:43', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('13', 'event', '1', 'submitted', NULL, '7', '2026-08-13 19:55:34', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('14', 'event', '1', 'approved', NULL, '2', '2026-08-13 19:55:45', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('15', 'event', '1', 'published', NULL, '2', '2026-08-13 19:55:45', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('16', 'resolution', '5', 'submitted', NULL, NULL, '2026-08-13 19:57:04', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('17', 'resolution', '5', 'voting', NULL, NULL, '2026-08-13 19:57:04', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('18', 'resolution', '5', 'passed', NULL, NULL, '2026-08-13 19:57:04', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('19', 'resolution', '5', 'applied', NULL, NULL, '2026-08-13 19:57:04', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('20', 'document', '1', 'submitted', NULL, '7', '2026-08-14 09:40:40', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('21', 'document', '1', 'approved', NULL, '2', '2026-08-14 09:40:41', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('22', 'document', '1', 'published', NULL, '2', '2026-08-14 09:40:41', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('23', 'resolution', '7', 'passed', NULL, NULL, '2026-08-14 13:21:05', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('24', 'resolution', '7', 'applied', NULL, NULL, '2026-08-14 13:21:05', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('25', 'resolution', '8', 'passed', NULL, NULL, '2026-08-14 13:21:35', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('26', 'resolution', '8', 'applied', NULL, NULL, '2026-08-14 13:21:35', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('27', 'resolution', '9', 'passed', NULL, NULL, '2026-08-14 13:22:22', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('28', 'resolution', '9', 'applied', NULL, NULL, '2026-08-14 13:22:22', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('29', 'article', '7', 'submitted', NULL, '9', '2026-08-14 13:23:07', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('30', 'article', '7', 'under_review', NULL, '1', '2026-08-14 13:23:30', NULL, 'auto-staged by approver');
INSERT INTO `workflow_states` VALUES ('31', 'article', '7', 'approved', NULL, '1', '2026-08-14 13:23:30', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('32', 'article', '7', 'published', NULL, '1', '2026-08-14 13:23:30', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('33', 'article', '8', 'submitted', NULL, '7', '2026-08-14 13:35:22', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('35', 'article', '10', 'submitted', NULL, '9', '2026-08-14 15:59:25', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('36', 'article', '10', 'under_review', NULL, '1', '2026-08-14 15:59:56', NULL, 'auto-staged by approver');
INSERT INTO `workflow_states` VALUES ('37', 'article', '10', 'approved', NULL, '1', '2026-08-14 15:59:56', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('38', 'article', '10', 'published', NULL, '1', '2026-08-14 15:59:56', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('39', 'event', '6', 'submitted', NULL, '9', '2026-08-14 15:59:56', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('40', 'event', '6', 'approved', NULL, '1', '2026-08-14 15:59:56', NULL, NULL);
INSERT INTO `workflow_states` VALUES ('41', 'event', '6', 'published', NULL, '1', '2026-08-14 15:59:56', NULL, NULL);

DROP TABLE IF EXISTS `working_group_members`;
CREATE TABLE `working_group_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role` enum('chair','member','secretary','advisor') DEFAULT 'member',
  `status` enum('active','inactive') DEFAULT 'active',
  `joined_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_wg_member` (`group_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `working_group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `working_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `working_group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `working_group_members` VALUES ('1', '1', '5', 'chair', 'active', '2026-08-18', '2026-08-18 09:33:55');
INSERT INTO `working_group_members` VALUES ('2', '2', '3', 'chair', 'active', '2026-08-18', '2026-08-18 09:33:55');
INSERT INTO `working_group_members` VALUES ('3', '3', '4', 'chair', 'active', '2026-08-18', '2026-08-18 09:33:55');
INSERT INTO `working_group_members` VALUES ('4', '4', '2', 'chair', 'active', '2026-08-18', '2026-08-18 09:33:55');

DROP TABLE IF EXISTS `working_groups`;
CREATE TABLE `working_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('committee','working_group','task_force','sub_committee') DEFAULT 'working_group',
  `status` enum('active','inactive','dissolved') DEFAULT 'active',
  `chair_id` int(11) DEFAULT NULL,
  `programme_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `resolution_id` int(11) DEFAULT NULL,
  `term_start` date DEFAULT NULL,
  `term_end` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `chair_id` (`chair_id`),
  KEY `programme_id` (`programme_id`),
  KEY `created_by` (`created_by`),
  KEY `resolution_id` (`resolution_id`),
  CONSTRAINT `working_groups_ibfk_1` FOREIGN KEY (`chair_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `working_groups_ibfk_2` FOREIGN KEY (`programme_id`) REFERENCES `programmes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `working_groups_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `working_groups_ibfk_4` FOREIGN KEY (`resolution_id`) REFERENCES `resolutions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `working_groups` VALUES ('1', 'Education Working Group', 'Oversees astronomy education programmes in schools and universities', 'working_group', 'active', '5', NULL, '1', NULL, '2026-08-18', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `working_groups` VALUES ('2', 'Outreach Committee', 'Plans and coordinates public observing events and community outreach', 'committee', 'active', '3', NULL, '1', NULL, '2026-08-18', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `working_groups` VALUES ('3', 'Technical Task Force', 'Handles telescope maintenance, observatory operations, and technical infrastructure', 'task_force', 'active', '4', NULL, '1', NULL, '2026-08-18', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');
INSERT INTO `working_groups` VALUES ('4', 'Finance & Governance Committee', 'Oversees financial planning, budgets, and governance compliance', 'committee', 'active', '2', NULL, '1', NULL, '2026-08-18', NULL, '2026-08-18 09:33:55', '2026-08-18 09:33:55');

SET FOREIGN_KEY_CHECKS = 1;
